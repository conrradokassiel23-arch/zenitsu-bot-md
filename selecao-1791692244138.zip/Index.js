/* ============================================================
   🎩 NAPOLEÃO BONAPARTE - MD
   ============================================================ */

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
  downloadMediaMessage
} = require("@itsliaaa/baileys")
const { Boom } = require("@hapi/boom")
const P = require("pino")
const fs = require("fs")
const path = require("path")
const readline = require("readline")

const config = require("./config")

const DATA_DIR = path.join(__dirname, "data")
const MENUS_DIR = path.join(__dirname, "menus")

// ============================================================
// 📁 BOOTSTRAP
// ============================================================
function bootstrap() {
  const pastas = [
    DATA_DIR,
    path.join(DATA_DIR, "fnaf-assets"),
    MENUS_DIR,
    path.join(MENUS_DIR, "menu-adm"),
    path.join(MENUS_DIR, "menu-dono"),
    path.join(MENUS_DIR, "menu-vip"),
    path.join(MENUS_DIR, "menu-rpg"),
    path.join(MENUS_DIR, "menu-fazenda"),
    path.join(MENUS_DIR, "menu-fnaf"),
    path.join(MENUS_DIR, "menu-cidade")
  ]
  for (const pasta of pastas) {
    if (!fs.existsSync(pasta)) {
      try {
        fs.mkdirSync(pasta, { recursive: true })
        console.log("📁 Pasta criada: " + pasta)
      } catch (e) {
        console.log("❌ Erro ao criar " + pasta + ":", e.message)
      }
    }
  }

  // 📝 Placeholder do menu-cidade
  const arquivoCidade = path.join(MENUS_DIR, "menu-cidade", "index.js")
  if (!fs.existsSync(arquivoCidade)) {
    try {
      const template = `/* ============================================================
   🏙️ MENU CIDADE - NAPOLEÃO BONAPARTE
   ⚠️ PLACEHOLDER - substitua pelo menu-cidade completo
   ============================================================ */

module.exports = {
  menu: "menu-cidade",
  grupoOnly: false,
  adminOnly: false,
  donoOnly: false,

  commands: {
    menucidade: {
      aliases: ["cidade", "menuc"],
      async executar({ sock, msg }) {
        await sock.sendMessage(msg.key.remoteJid, {
          text: "🏙️ *MENU CIDADE*\\n\\n⚠️ Ainda não foi instalado!\\n\\n📝 Coloque o menu-cidade completo em:\\n*menus/menu-cidade/index.js*"
        }, { quoted: msg })
      }
    }
  }
}
`
      fs.writeFileSync(arquivoCidade, template, "utf8")
      console.log("📝 Placeholder criado: menus/menu-cidade/index.js")
      console.log("⚠️  Substitua pelo menu-cidade completo!")
    } catch (e) {
      console.log("❌ Erro ao criar placeholder:", e.message)
    }
  }

  // 🏙️ Arquivo cidade.json
  const arquivoCidadeJson = path.join(DATA_DIR, "cidade.json")
  if (!fs.existsSync(arquivoCidadeJson)) {
    try {
      fs.writeFileSync(arquivoCidadeJson, JSON.stringify({
        usuarios: {},
        casas: {},
        predios: {}
      }, null, 2))
      console.log("🏙️ cidade.json criado!")
    } catch (e) {
      console.log("❌ Erro ao criar cidade.json:", e.message)
    }
  }
}
bootstrap()

// ============================================================
// 💾 DB
// ============================================================
function dbLer(arquivo, padrao = {}) {
  const p = path.join(DATA_DIR, arquivo)
  if (!fs.existsSync(p)) {
    fs.writeFileSync(p, JSON.stringify(padrao, null, 2))
    return padrao
  }
  try { return JSON.parse(fs.readFileSync(p, "utf8")) } catch { return padrao }
}

function dbSalvar(arquivo, dados) {
  fs.writeFileSync(path.join(DATA_DIR, arquivo), JSON.stringify(dados, null, 2))
}

const db = {
  grupos: () => dbLer("grupos.json", {}),
  salvarGrupos: (d) => dbSalvar("grupos.json", d),
  advs: () => dbLer("advs.json", {}),
  salvarAdvs: (d) => dbSalvar("advs.json", d),
  config: () => dbLer("config.json", { fotoMenu: null, prefixoGlobal: null, apiKey: null, slow: false, subdonos: [] }),
  salvarConfig: (d) => dbSalvar("config.json", d),
  canal: () => dbLer("canal.json", { jid: null, nome: null, link: null }),
  salvarCanal: (d) => dbSalvar("canal.json", d),
  listanegra: () => dbLer("listanegra.json", {}),
  salvarListanegra: (d) => dbSalvar("listanegra.json", d),
  aluguel: () => dbLer("aluguel.json", { ativo: false, grupos: {} }),
  salvarAluguel: (d) => dbSalvar("aluguel.json", d),
  parcerias: () => dbLer("parcerias.json", {}),
  salvarParcerias: (d) => dbSalvar("parcerias.json", d),
  avisos: () => dbLer("avisos.json", {}),
  salvarAvisos: (d) => dbSalvar("avisos.json", d),
  afk: () => dbLer("afk.json", {}),
  salvarAfk: (d) => dbSalvar("afk.json", d),
  mutados: () => dbLer("mutados.json", {}),
  salvarMutados: (d) => dbSalvar("mutados.json", d),
  palavroes: () => dbLer("palavroes.json", {}),
  salvarPalavroes: (d) => dbSalvar("palavroes.json", d),
  subadmins: () => dbLer("subadmins.json", {}),
  salvarSubadmins: (d) => dbSalvar("subadmins.json", d),
  vips: () => dbLer("vips.json", { vips: {} }),
  salvarVips: (d) => dbSalvar("vips.json", d),
  bangp: () => dbLer("bangp.json", { grupos: {} }),
  salvarBangp: (d) => dbSalvar("bangp.json", d),
  rpg: () => dbLer("rpg.json", { usuarios: {} }),
  salvarRpg: (d) => dbSalvar("rpg.json", d)
}

// ============================================================
// 🛠️ HELPERS
// ============================================================
function getAlvo(msg) {
  const ctx =
    msg.message?.extendedTextMessage?.contextInfo ||
    msg.message?.imageMessage?.contextInfo ||
    msg.message?.videoMessage?.contextInfo ||
    {}
  const mentions = ctx.mentionedJid || []
  if (mentions.length) return mentions[0]
  if (ctx.participant) return ctx.participant
  return null
}

function soNumero(jid) {
  if (!jid) return ""
  if (typeof jid === "object") jid = jid.phoneNumber || jid.id || ""
  return String(jid).split("@")[0].split(":")[0].replace(/\D/g, "")
}

function getTexto(msg) {
  return (
    msg.message?.conversation ||
    msg.message?.extendedTextMessage?.text ||
    msg.message?.imageMessage?.caption ||
    msg.message?.videoMessage?.caption ||
    ""
  )
}

function getTextoBotao(msg) {
  try {
    if (msg.message?.buttonsResponseMessage) return msg.message.buttonsResponseMessage.selectedButtonId || ""
    if (msg.message?.templateButtonReplyMessage) return msg.message.templateButtonReplyMessage.selectedId || ""
    if (msg.message?.listResponseMessage) return msg.message.listResponseMessage.singleSelectReply?.selectedRowId || ""
    if (msg.message?.interactiveResponseMessage) {
      const nfr = msg.message.interactiveResponseMessage.nativeFlowResponseMessage
      if (nfr?.paramsJson) {
        try {
          const parsed = typeof nfr.paramsJson === "string" ? JSON.parse(nfr.paramsJson) : nfr.paramsJson
          return parsed.id || parsed.selectedId || ""
        } catch { return "" }
      }
    }
  } catch (_) {}
  return ""
}

function naListaNegra(jidGrupo, jidOuNum) {
  const num = soNumero(jidOuNum)
  if (!num) return false
  return (db.listanegra()[jidGrupo] || []).includes(num)
}

function aluguelAtivo() { return db.aluguel().ativo === true }

function grupoTemAluguel(jid) {
  const a = db.aluguel()
  const exp = a.grupos?.[jid]
  return exp && Date.now() < exp
}

function formatarTempo(ms) {
  const s = Math.floor(ms / 1000)
  const m = Math.floor(s / 60)
  const h = Math.floor(m / 60)
  const d = Math.floor(h / 24)
  if (d > 0) return d + "d " + (h % 24) + "h"
  if (h > 0) return h + "h " + (m % 60) + "min"
  if (m > 0) return m + "min " + (s % 60) + "s"
  return s + "s"
}

function adicionarAviso(grupoJid, userJid, tipo) {
  const avisos = db.avisos()
  avisos[grupoJid] = avisos[grupoJid] || {}
  avisos[grupoJid][userJid] = avisos[grupoJid][userJid] || {}
  avisos[grupoJid][userJid][tipo] = (avisos[grupoJid][userJid][tipo] || 0) + 1
  db.salvarAvisos(avisos)
  return avisos[grupoJid][userJid][tipo]
}

function limparAvisos(grupoJid, userJid, tipo) {
  const avisos = db.avisos()
  if (avisos[grupoJid]?.[userJid]?.[tipo]) {
    avisos[grupoJid][userJid][tipo] = 0
    db.salvarAvisos(avisos)
  }
}

function ehSubAdmin(jidGrupo, jidUser) {
  const subs = db.subadmins()[jidGrupo] || []
  const num = soNumero(jidUser)
  return subs.some(s => soNumero(s) === num)
}

function botEhAdmin(meta, sock) {
  if (!meta) return false
  const botIds = [sock.user?.id, sock.user?.lid, sock.user?.jid].filter(Boolean).map(soNumero)
  const botPart = meta.participants.find(p => {
    const ids = [p.id, p.lid, p.phoneNumber].filter(Boolean).map(soNumero)
    return ids.some(id => botIds.includes(id))
  })
  return botPart?.admin === "admin" || botPart?.admin === "superadmin"
}

function dataBrasil() {
  return new Date().toLocaleString("pt-BR", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).split("/").reverse().join("-")
}

async function notificarX9(sock, groupJid, tipo, autor, alvo) {
  try {
    const conf = db.grupos()[groupJid] || {}
    if (!conf.x9) return
    const meta = await sock.groupMetadata(groupJid)
    const autorNum = soNumero(autor)
    const alvoNum = alvo ? soNumero(alvo) : null
    const nomeGrupo = meta.subject || "Grupo"
    const hora = new Date().toLocaleString("pt-BR")
    let texto = ""
    if (tipo === "PROMOTE") texto = "X9 - @" + autorNum + " promoveu @" + alvoNum + "\n" + nomeGrupo + "\n" + hora
    else if (tipo === "DEMOTE") texto = "X9 - @" + autorNum + " rebaixou @" + alvoNum + "\n" + nomeGrupo + "\n" + hora
    else if (tipo === "REMOVE") texto = "X9 - @" + autorNum + " removeu @" + alvoNum + "\n" + nomeGrupo + "\n" + hora
    else return
    await sock.sendMessage(groupJid, { text: texto, mentions: [autor, alvo].filter(Boolean) })
  } catch (e) { console.log("X9 erro:", e.message) }
}

// ============================================================
// 📦 CARREGADOR DE MENUS
// ============================================================
const comandos = new Map()
const aliases = new Map()

global.rendasAutomaticas = global.rendasAutomaticas || []

function carregarMenus() {
  if (!fs.existsSync(MENUS_DIR)) return
  const pastas = fs.readdirSync(MENUS_DIR)
  for (const pasta of pastas) {
    const caminhoPasta = path.join(MENUS_DIR, pasta)
    if (!fs.statSync(caminhoPasta).isDirectory()) continue
    const arquivo = path.join(caminhoPasta, "index.js")
    if (!fs.existsSync(arquivo)) continue
    try {
      delete require.cache[require.resolve(arquivo)]
      const mod = require(arquivo)
      if (!mod.commands) continue

      if (typeof mod.rendaAutomatica === "function") {
        global.rendasAutomaticas.push(mod.rendaAutomatica)
        console.log("[" + pasta + "] renda automatica registrada!")
      }

      const menuCfg = {
        grupoOnly: mod.grupoOnly ?? false,
        adminOnly: mod.adminOnly ?? false,
        donoOnly: mod.donoOnly ?? false
      }
      for (const [nome, cmd] of Object.entries(mod.commands)) {
        const pacote = {
          nome,
          aliases: cmd.aliases || [],
          categoria: mod.menu || pasta,
          grupoOnly: cmd.grupoOnly ?? menuCfg.grupoOnly,
          adminOnly: cmd.adminOnly ?? menuCfg.adminOnly,
          donoOnly: cmd.donoOnly ?? menuCfg.donoOnly,
          executar: cmd.executar
        }
        comandos.set(nome, pacote)
        for (const a of pacote.aliases) aliases.set(a, nome)
        console.log("[" + pasta + "] " + nome + " ~ carregado!")
      }
    } catch (e) {
      console.log("Erro ao carregar " + pasta + ":", e.message)
      console.log(e.stack)
    }
  }

  const categorias = {}
  for (const [nome, cmd] of comandos.entries()) {
    const cat = cmd.categoria || "outros"
    categorias[cat] = (categorias[cat] || 0) + 1
  }
  global.totalComandos = comandos.size
  global.totalAliases = aliases.size
  global.comandosPorCategoria = categorias

  console.log("\nNapoleao carregou " + comandos.size + " comandos...")
  console.log(aliases.size + " aliases registrados\n")
}

function getComando(n) {
  if (comandos.has(n)) return comandos.get(n)
  if (aliases.has(n)) return comandos.get(aliases.get(n))
  return null
}

function similaridade(a, b) {
  a = String(a).toLowerCase(); b = String(b).toLowerCase()
  const m = a.length, n = b.length
  if (m === 0 || n === 0) return 0
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0))
  for (let i = 0; i <= m; i++) dp[i][0] = i
  for (let j = 0; j <= n; j++) dp[0][j] = j
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++) {
      const c = a[i - 1] === b[j - 1] ? 0 : 1
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + c)
    }
  const dist = dp[m][n], maxLen = Math.max(m, n)
  return Math.round((1 - dist / maxLen) * 100)
}

function comandosParecidos(d, limite = 3) {
  const r = []
  for (const [nome, cmd] of comandos.entries()) {
    let melhor = { comando: nome, porcentagem: similaridade(d, nome) }
    for (const a of cmd.aliases) {
      const p = similaridade(d, a)
      if (p > melhor.porcentagem) melhor = { comando: nome, porcentagem: p }
    }
    if (melhor.porcentagem > 0) r.push(melhor)
  }
  r.sort((a, b) => b.porcentagem - a.porcentagem)
  return r.slice(0, limite).filter(x => x.porcentagem >= 40)
}

let canalCache = null
function recarregarCanal() { canalCache = db.canal() }

function envolverSendMessage(sock) {
  const original = sock.sendMessage.bind(sock)
  sock.sendMessage = async (jid, content, options = {}) => {
    try {
      const temBotoes =
        content?.buttons ||
        content?.sections ||
        content?.templateButtons ||
        content?.buttonText ||
        content?.interactiveButtons ||
        content?.listMessage

      if (temBotoes) return original(jid, content, options)
      if (options.edit) return original(jid, content, options)

      if (!canalCache) recarregarCanal()
      const c = canalCache
      if (c && c.jid && c.jid !== "0@newsletter") {
        content.contextInfo = content.contextInfo || {}
        content.contextInfo.forwardedNewsletterMessageInfo = {
          newsletterJid: c.jid,
          newsletterName: c.nome || "Canal",
          serverMessageId: 0
        }
        content.contextInfo.forwardingScore = 1
        content.contextInfo.isForwarded = true
      }
    } catch (_) {}
    return original(jid, content, options)
  }
}

// ============================================================
// 🎮 POKÉMONS
// ============================================================
const POKEMONS_LISTA = [
  { id: 1, nome: "Bulbasaur", tipo: "Grama", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/1.png" },
  { id: 4, nome: "Charmander", tipo: "Fogo", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/4.png" },
  { id: 7, nome: "Squirtle", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/7.png" },
  { id: 25, nome: "Pikachu", tipo: "Elétrico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/25.png" },
  { id: 6, nome: "Charizard", tipo: "Fogo", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/6.png" },
  { id: 9, nome: "Blastoise", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/9.png" },
  { id: 3, nome: "Venusaur", tipo: "Grama", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/3.png" },
  { id: 150, nome: "Mewtwo", tipo: "Psíquico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/150.png" },
  { id: 151, nome: "Mew", tipo: "Psíquico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/151.png" },
  { id: 94, nome: "Gengar", tipo: "Fantasma", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/94.png" },
  { id: 149, nome: "Dragonite", tipo: "Dragão", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/149.png" },
  { id: 143, nome: "Snorlax", tipo: "Normal", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/143.png" },
  { id: 130, nome: "Gyarados", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/130.png" },
  { id: 65, nome: "Alakazam", tipo: "Psíquico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/65.png" },
  { id: 68, nome: "Machamp", tipo: "Lutador", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/68.png" },
  { id: 59, nome: "Arcanine", tipo: "Fogo", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/59.png" },
  { id: 134, nome: "Vaporeon", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/134.png" },
  { id: 135, nome: "Jolteon", tipo: "Elétrico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/135.png" },
  { id: 136, nome: "Flareon", tipo: "Fogo", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/136.png" },
  { id: 131, nome: "Lapras", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/131.png" },
  { id: 133, nome: "Eevee", tipo: "Normal", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/133.png" },
  { id: 39, nome: "Jigglypuff", tipo: "Normal", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/39.png" },
  { id: 52, nome: "Meowth", tipo: "Normal", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/52.png" },
  { id: 54, nome: "Psyduck", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/54.png" },
  { id: 58, nome: "Growlithe", tipo: "Fogo", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/58.png" },
  { id: 63, nome: "Abra", tipo: "Psíquico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/63.png" },
  { id: 66, nome: "Machop", tipo: "Lutador", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/66.png" },
  { id: 74, nome: "Geodude", tipo: "Pedra", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/74.png" },
  { id: 92, nome: "Gastly", tipo: "Fantasma", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/92.png" },
  { id: 95, nome: "Onix", tipo: "Pedra", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/95.png" },
  { id: 104, nome: "Cubone", tipo: "Terra", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/104.png" },
  { id: 113, nome: "Chansey", tipo: "Normal", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/113.png" },
  { id: 123, nome: "Scyther", tipo: "Inseto", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/123.png" },
  { id: 127, nome: "Pinsir", tipo: "Inseto", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/127.png" },
  { id: 129, nome: "Magikarp", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/129.png" },
  { id: 142, nome: "Aerodactyl", tipo: "Pedra", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/142.png" },
  { id: 144, nome: "Articuno", tipo: "Gelo", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/144.png" },
  { id: 145, nome: "Zapdos", tipo: "Elétrico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/145.png" },
  { id: 146, nome: "Moltres", tipo: "Fogo", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/146.png" },
  { id: 147, nome: "Dratini", tipo: "Dragão", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/147.png" },
  { id: 148, nome: "Dragonair", tipo: "Dragão", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/148.png" },
  { id: 152, nome: "Chikorita", tipo: "Grama", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/152.png" },
  { id: 155, nome: "Cyndaquil", tipo: "Fogo", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/155.png" },
  { id: 158, nome: "Totodile", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/158.png" },
  { id: 175, nome: "Togepi", tipo: "Fada", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/175.png" },
  { id: 196, nome: "Espeon", tipo: "Psíquico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/196.png" },
  { id: 197, nome: "Umbreon", tipo: "Sombrio", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/197.png" },
  { id: 208, nome: "Steelix", tipo: "Aço", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/208.png" },
  { id: 212, nome: "Scizor", tipo: "Inseto", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/212.png" },
  { id: 214, nome: "Heracross", tipo: "Inseto", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/214.png" },
  { id: 229, nome: "Houndoom", tipo: "Sombrio", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/229.png" },
  { id: 248, nome: "Tyranitar", tipo: "Pedra", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/248.png" },
  { id: 249, nome: "Lugia", tipo: "Psíquico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/249.png" },
  { id: 250, nome: "Ho-Oh", tipo: "Fogo", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/250.png" },
  { id: 251, nome: "Celebi", tipo: "Psíquico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/251.png" },
  { id: 384, nome: "Rayquaza", tipo: "Dragão", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/384.png" },
  { id: 445, nome: "Garchomp", tipo: "Dragão", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/445.png" },
  { id: 448, nome: "Lucario", tipo: "Lutador", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/448.png" },
  { id: 493, nome: "Arceus", tipo: "Normal", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/493.png" },
  { id: 658, nome: "Greninja", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/658.png" },
  { id: 700, nome: "Sylveon", tipo: "Fada", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/700.png" },
  { id: 778, nome: "Mimikyu", tipo: "Fantasma", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/778.png" },
  { id: 887, nome: "Dragapult", tipo: "Dragão", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/887.png" },
  { id: 10, nome: "Caterpie", tipo: "Inseto", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/10.png" },
  { id: 13, nome: "Weedle", tipo: "Inseto", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/13.png" },
  { id: 16, nome: "Pidgey", tipo: "Normal", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/16.png" },
  { id: 19, nome: "Rattata", tipo: "Normal", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/19.png" },
  { id: 21, nome: "Spearow", tipo: "Normal", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/21.png" },
  { id: 41, nome: "Zubat", tipo: "Venenoso", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/41.png" },
  { id: 46, nome: "Paras", tipo: "Inseto", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/46.png" },
  { id: 50, nome: "Diglett", tipo: "Terra", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/50.png" },
  { id: 56, nome: "Mankey", tipo: "Lutador", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/56.png" },
  { id: 60, nome: "Poliwag", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/60.png" },
  { id: 69, nome: "Bellsprout", tipo: "Grama", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/69.png" },
  { id: 72, nome: "Tentacool", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/72.png" },
  { id: 81, nome: "Magnemite", tipo: "Elétrico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/81.png" },
  { id: 96, nome: "Drowzee", tipo: "Psíquico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/96.png" },
  { id: 100, nome: "Voltorb", tipo: "Elétrico", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/100.png" },
  { id: 109, nome: "Koffing", tipo: "Venenoso", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/109.png" },
  { id: 118, nome: "Goldeen", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/118.png" },
  { id: 120, nome: "Staryu", tipo: "Água", foto: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/120.png" }
]

const RARIDADE = { comum: 80, incomum: 40, raro: 15, lendario: 3 }

const RARIDADE_POKEMON = {
  129: "comum", 10: "comum", 13: "comum", 16: "comum", 19: "comum",
  21: "comum", 41: "comum", 46: "comum", 50: "comum", 52: "comum",
  54: "comum", 56: "comum", 60: "comum", 69: "comum", 72: "comum",
  74: "comum", 81: "comum", 96: "comum", 100: "comum", 109: "comum",
  118: "comum", 120: "comum", 39: "comum", 133: "comum",
  1: "incomum", 4: "incomum", 7: "incomum", 25: "incomum", 63: "incomum",
  66: "incomum", 92: "incomum", 95: "incomum", 104: "incomum", 113: "incomum",
  123: "incomum", 127: "incomum", 147: "incomum", 152: "incomum",
  155: "incomum", 158: "incomum", 175: "incomum", 196: "incomum",
  197: "incomum", 58: "incomum", 134: "incomum", 135: "incomum",
  136: "incomum", 131: "incomum", 148: "incomum", 142: "incomum",
  3: "raro", 6: "raro", 9: "raro", 65: "raro", 68: "raro", 94: "raro",
  130: "raro", 143: "raro", 149: "raro", 208: "raro", 212: "raro",
  214: "raro", 229: "raro", 248: "raro", 445: "raro", 448: "raro",
  658: "raro", 700: "raro", 778: "raro", 887: "raro",
  150: "lendario", 151: "lendario", 144: "lendario", 145: "lendario",
  146: "lendario", 249: "lendario", 250: "lendario", 251: "lendario",
  384: "lendario", 493: "lendario"
}

function sortearPokemon() {
  const pool = POKEMONS_LISTA.map(p => ({
    poke: p,
    peso: RARIDADE[RARIDADE_POKEMON[p.id] || "incomum"]
  }))
  const totalPeso = pool.reduce((s, x) => s + x.peso, 0)
  let r = Math.random() * totalPeso
  for (const item of pool) {
    r -= item.peso
    if (r <= 0) return item.poke
  }
  return pool[0].poke
}

// ============================================================
// 🚀 START
// ============================================================
let NUMERO_PAREAMENTO = null
let sockGlobal = null

async function iniciar() {
  const { state, saveCreds } = await useMultiFileAuthState("auth")
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    logger: P({ level: "silent" }),
    auth: state,
    printQRInTerminal: false,
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 0,
    keepAliveIntervalMs: 30000,
    syncFullHistory: false
  })

  sockGlobal = sock
  recarregarCanal()
  envolverSendMessage(sock)
  sock.ev.on("creds.update", saveCreds)

  if (!state.creds.registered) {
    setTimeout(async () => {
      try {
        console.log("\n═══════════════════════════════")
        console.log("   NAPOLEAO BONAPARTE - MD")
        console.log("═══════════════════════════════")
        console.log("")
        console.log("Digite o NUMERO do bot (com DDI, so digitos):")
        console.log("Exemplo: 5511999999999")
        console.log("")

        const rl = readline.createInterface({
          input: process.stdin,
          output: process.stdout
        })

        rl.question("Numero: ", async (numeroDigitado) => {
          rl.close()
          const numero = String(numeroDigitado).replace(/\D/g, "")

          if (!numero || numero.length < 10) {
            console.log("\nNumero invalido! Reinicie o bot.")
            process.exit(1)
          }

          NUMERO_PAREAMENTO = numero
          console.log("\nNumero salvo: " + numero)
          console.log("Gerando codigo de pareamento...\n")

          try {
            const code = await sock.requestPairingCode(numero)
            console.log("╔═══════════════════════════════╗")
            console.log("║   CODIGO DE PAREAMENTO        ║")
            console.log("╠═══════════════════════════════╣")
            console.log("║   " + code + "                       ║")
            console.log("╚═══════════════════════════════╝")
            console.log("")
            console.log("Digite esse codigo no WhatsApp:")
            console.log("WhatsApp > Aparelhos conectados > Conectar > Conectar com numero")
            console.log("")
          } catch (e) {
            console.log("Erro ao gerar codigo:", e.message)
          }
        })
      } catch (e) {
        console.log("Erro:", e.message)
      }
    }, 5000)
  }

  sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
    if (connection === "close") {
      const motivo = new Boom(lastDisconnect?.error)?.output?.statusCode
      if (motivo === DisconnectReason.loggedOut) process.exit(1)
      else setTimeout(() => iniciar(), 3000)
    } else if (connection === "open") {
      console.log("\nCONECTADO! Napoleao Bonaparte online\n")
    }
  })

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return
    const msg = messages[0]
    if (!msg.message) return

    const remetente = msg.key.remoteJid
    const isGrupo = remetente.endsWith("@g.us")

    let senderRaw = isGrupo ? msg.key.participant : remetente
    let sender = senderRaw

    if (senderRaw && senderRaw.endsWith("@lid")) {
      if (msg.key?.participantPn) sender = msg.key.participantPn
      else if (msg.key?.participantAlt) sender = msg.key.participantAlt
      else if (isGrupo) {
        try {
          const meta = await sock.groupMetadata(remetente).catch(() => null)
          if (meta) {
            const p = meta.participants.find(x =>
              x.lid === senderRaw || x.id === senderRaw ||
              (x.lid && soNumero(x.lid) === soNumero(senderRaw))
            )
            if (p?.phoneNumber) sender = p.phoneNumber
            else if (p?.id && !p.id.endsWith("@lid")) sender = p.id
          }
        } catch (_) {}
      }
    }

    const numerosDono = (Array.isArray(config.dono) ? config.dono : [config.dono]).map(soNumero)
    const senderCandidatos = [
      sender, senderRaw,
      msg.key?.participant, msg.key?.participantPn,
      msg.key?.participantLid, msg.key?.remoteJid, msg.participant,
      sock.user?.id, sock.user?.lid
    ].filter(Boolean)
    const senderNums = senderCandidatos.map(soNumero).filter(Boolean)
    const isDono = msg.key.fromMe === true || senderNums.some(n => numerosDono.includes(n))

    const cfgSub = db.config()
    const numerosSub = (cfgSub.subdonos || []).map(soNumero)
    const isSubDono = senderNums.some(n => numerosSub.includes(n)) && !isDono

    if (isGrupo && !isDono && !isSubDono) {
      const b = db.bangp()
      if (b.grupos?.[remetente]) return
    }

    // 💰 GOLD DIÁRIO
    if (isGrupo && !msg.key.fromMe) {
      try {
        const grupos = db.grupos()
        const conf = grupos[remetente] || {}

        if (conf.rpgAtivo === true) {
          const rpg = db.rpg()
          const dataHoje = dataBrasil()
          const num = soNumero(sender)

          rpg.usuarios = rpg.usuarios || {}
          rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }

          if (rpg.usuarios[num].ultimoGanho !== dataHoje) {
            rpg.usuarios[num].moedas = (rpg.usuarios[num].moedas || 0) + 100
            rpg.usuarios[num].ultimoGanho = dataHoje
            db.salvarRpg(rpg)
            await sock.sendMessage(remetente, {
              text: "Gold diario! +100 pra @" + num + "\nSaldo: " + rpg.usuarios[num].moedas,
              mentions: [sender]
            })
          }
        }
      } catch (_) {}
    }

    if (isGrupo && aluguelAtivo() && !isDono && !isSubDono && !grupoTemAluguel(remetente)) return

    if (isGrupo && !msg.key.fromMe) {
      const cands = [sender, msg.key?.participantPn, msg.key?.participantLid].filter(Boolean)
      if (cands.some(j => naListaNegra(remetente, j))) {
        try { await sock.sendMessage(remetente, { delete: msg.key }) } catch (_) {}
        try { await sock.groupParticipantsUpdate(remetente, [sender], "remove") } catch (_) {}
        return
      }
    }

    if (isGrupo && !msg.key.fromMe) {
      const grupos = db.grupos()
      const conf = grupos[remetente] || {}
      const meta = await sock.groupMetadata(remetente).catch(() => null)

      const isAdm = meta?.participants.find(p =>
        p.id === sender || soNumero(p.id) === soNumero(sender) || soNumero(p.lid) === soNumero(sender)
      )?.admin
      const ehAdmin = isAdm === "admin" || isAdm === "superadmin"
      const ehSub = ehSubAdmin(remetente, sender)
      const podeBurlar = ehAdmin || isDono || isSubDono || ehSub

      const mutados = db.mutados()
      const mutadosG = mutados[remetente] || {}
      const candsM = [sender, msg.key?.participantPn, msg.key?.participantLid].filter(Boolean)
      let jidMutado = null
      for (const c of candsM) {
        for (const j of Object.keys(mutadosG)) {
          if (soNumero(j) === soNumero(c) && mutadosG[j] > Date.now()) { jidMutado = j; break }
        }
        if (jidMutado) break
      }
      if (jidMutado && !podeBurlar) {
        try { await sock.sendMessage(remetente, { delete: msg.key }) } catch (_) {}
        return
      }

      if (conf.palavrao && !podeBurlar) {
        const lista = db.palavroes()[remetente] || []
        const normalizar = (s) => String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^\w\s]/g, " ").replace(/\s+/g, " ").trim()
        const textoNorm = normalizar(getTexto(msg))
        const temPalavrao = lista.some(p => {
          const pl = normalizar(p)
          if (!pl) return false
          const regex = new RegExp("\\b" + pl.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "i")
          return regex.test(textoNorm)
        })
        if (lista.length && textoNorm && temPalavrao) {
          try { await sock.sendMessage(remetente, { delete: msg.key }) } catch (_) {}
          const n = adicionarAviso(remetente, sender, "palavrao")
          if (n >= 3) {
            limparAvisos(remetente, sender, "palavrao")
            await sock.sendMessage(remetente, { text: "@" + soNumero(sender) + " 3/3 palavras proibidas!", mentions: [sender] })
            try { await sock.groupParticipantsUpdate(remetente, [sender], "remove") } catch (_) {}
          } else {
            await sock.sendMessage(remetente, { text: "@" + soNumero(sender) + " palavra proibida - " + n + "/3", mentions: [sender] })
          }
          return
        }
      }

      const afks = db.afk()
      const afkGrupo = afks[remetente] || {}
      const candsAutor = [sender, msg.key?.participantPn, msg.key?.participantLid].filter(Boolean)
      let jidAfk = null
      for (const c of candsAutor) {
        for (const j of Object.keys(afkGrupo)) {
          if (soNumero(j) === soNumero(c)) { jidAfk = j; break }
        }
        if (jidAfk) break
      }

      if (jidAfk && afkGrupo[jidAfk]) {
        const info = afkGrupo[jidAfk]
        const tempo = formatarTempo(Date.now() - info.desde)
        delete afkGrupo[jidAfk]
        afks[remetente] = afkGrupo
        db.salvarAfk(afks)
        await sock.sendMessage(remetente, {
          text: "@" + soNumero(jidAfk) + " voltou! Ficou AFK " + tempo,
          mentions: [jidAfk]
        })
      }

      const ctx = msg.message?.extendedTextMessage?.contextInfo || {}
      const mencionados = ctx.mentionedJid || []
      for (const m of mencionados) {
        for (const [j, info] of Object.entries(afkGrupo)) {
          if (soNumero(j) === soNumero(m)) {
            const tempo = formatarTempo(Date.now() - info.desde)
            await sock.sendMessage(remetente, {
              text: "AFK: @" + soNumero(j) + "\nHa " + tempo + "\nMotivo: " + info.motivo,
              mentions: [j]
            })
          }
        }
      }

      if (conf.antilink && !podeBurlar) {
        const textoMsg = getTexto(msg)
        const linkGrupo = /(chat\.whatsapp\.com|wa\.me\/)/i.test(textoMsg)
        const linkGeral = /(https?:\/\/|www\.|\.com|\.net|\.br|\.io|\.org|\.xyz|\.tv|\.me|\.gg)/i.test(textoMsg)

        if (linkGrupo) {
          const parcerias = db.parcerias()
          const p = parcerias[remetente] || {}
          const parceiros = p.parceiros || {}
          const modoParceria = p.ativo === true
          const senderNum = soNumero(sender)

          let encontrado = null
          for (const [jidP, info] of Object.entries(parceiros)) {
            if (soNumero(jidP) === senderNum) { encontrado = { jid: jidP, info }; break }
          }

          if (modoParceria && encontrado) {
            if (encontrado.info.usados < encontrado.info.total) {
              encontrado.info.usados++
              db.salvarParcerias(parcerias)
              await sock.sendMessage(remetente, {
                text: "Parceria liberada para @" + senderNum + "\nUsos: " + encontrado.info.usados + "/" + encontrado.info.total,
                mentions: [sender]
              })
              return
            } else {
              try { await sock.sendMessage(remetente, { delete: msg.key }) } catch (_) {}
              await sock.sendMessage(remetente, {
                text: "Parceria esgotada para @" + senderNum,
                mentions: [sender]
              })
              return
            }
          }

          try { await sock.sendMessage(remetente, { delete: msg.key }) } catch (_) {}
          const n = adicionarAviso(remetente, sender, "link")
          if (n >= 3) {
            limparAvisos(remetente, sender, "link")
            await sock.sendMessage(remetente, { text: "@" + senderNum + " 3/3 divulgacoes!", mentions: [sender] })
            try { await sock.groupParticipantsUpdate(remetente, [sender], "remove") } catch (_) {}
          } else {
            await sock.sendMessage(remetente, { text: "Divulgacao bloqueada! Avisos: " + n + "/3", mentions: [sender] })
          }
          return
        }

        if (linkGeral) {
          try { await sock.sendMessage(remetente, { delete: msg.key }) } catch (_) {}
          const n = adicionarAviso(remetente, sender, "link")
          if (n >= 3) {
            limparAvisos(remetente, sender, "link")
            await sock.sendMessage(remetente, { text: "@" + soNumero(sender) + " 3/3 links!", mentions: [sender] })
            try { await sock.groupParticipantsUpdate(remetente, [sender], "remove") } catch (_) {}
          } else {
            await sock.sendMessage(remetente, { text: "Link bloqueado! " + n + "/3", mentions: [sender] })
          }
          return
        }
      }

      const antimap = [
        { cond: conf.antiaudio && msg.message?.audioMessage, tipo: "audio", nome: "Audio" },
        { cond: conf.antivideo && msg.message?.videoMessage, tipo: "video", nome: "Video" },
        { cond: conf.antifoto && msg.message?.imageMessage, tipo: "foto", nome: "Foto" },
        { cond: conf.antifig && msg.message?.stickerMessage, tipo: "fig", nome: "Figurinha" }
      ]
      for (const a of antimap) {
        if (a.cond && !podeBurlar) {
          const n = adicionarAviso(remetente, sender, a.tipo)
          try { await sock.sendMessage(remetente, { delete: msg.key }) } catch (_) {}
          if (n >= 3) {
            limparAvisos(remetente, sender, a.tipo)
            await sock.sendMessage(remetente, { text: "@" + soNumero(sender) + " 3/3 " + a.nome + "s!", mentions: [sender] })
            try { await sock.groupParticipantsUpdate(remetente, [sender], "remove") } catch (_) {}
          } else {
            await sock.sendMessage(remetente, { text: a.nome + "! " + n + "/3", mentions: [sender] })
          }
          return
        }
      }
    }

    const hoje = dataBrasil()
    const cfgAll = db.config()
    if (cfgAll.ultimoReset !== hoje) {
      const parceriasAll = db.parcerias()
      for (const jid of Object.keys(parceriasAll)) {
        const p = parceriasAll[jid]
        if (p?.parceiros) {
          for (const jidP of Object.keys(p.parceiros)) p.parceiros[jidP].usados = 0
        }
      }
      db.salvarParcerias(parceriasAll)
      cfgAll.ultimoReset = hoje
      db.salvarConfig(cfgAll)
    }

    const grupos = db.grupos()
    const confGrupo = grupos[remetente] || {}
    const cfgGlobal = db.config()

    const prefixoGlobal = cfgGlobal.prefixoGlobal || config.prefixo || "!"
    let prefixosAtivos
    if (isGrupo && confGrupo.multiprefixo && confGrupo.prefixo) {
      prefixosAtivos = [confGrupo.prefixo]
    } else {
      prefixosAtivos = [prefixoGlobal]
    }

    let texto = getTexto(msg)

    const btnId = getTextoBotao(msg)
    if (btnId) {
      const prefixos = ["!", "/", ".", "-", "#", ","]
      const temPrefixo = prefixos.some(p => btnId.startsWith(p))
      texto = temPrefixo ? btnId : (prefixoGlobal || "!") + btnId
    }

    let prefixoUsado = prefixosAtivos.find(p => texto.startsWith(p))
    let cmdName = ""
    let args = []

    if (prefixoUsado) {
      const partes = texto.slice(prefixoUsado.length).trim().split(/\s+/)
      cmdName = partes[0]
      args = partes.slice(1)
    } else {
      const partes = texto.trim().split(/\s+/)
      const primeira = (partes[0] || "").toLowerCase()
      if (primeira === "prefixo") {
        cmdName = "prefixo"
        args = partes.slice(1)
        prefixoUsado = ""
      } else {
        return
      }
    }

    if (cmdName.toLowerCase() === "spaw" || cmdName.toLowerCase() === "spawn") {
      if (!isDono && !isSubDono) {
        return sock.sendMessage(remetente, { text: "So o imperador pode usar !spaw!" }, { quoted: msg })
      }
      const jidReal = remetente.split(":")[0]
      const spawns = dbLer("spawns.json", {})
      let poke
      if (args.length > 0) {
        const nomeBusca = args.join(" ").toLowerCase()
        poke = POKEMONS_LISTA.find(p => p.nome.toLowerCase() === nomeBusca)
                 || POKEMONS_LISTA.find(p => p.nome.toLowerCase().includes(nomeBusca))
        if (!poke) return sock.sendMessage(remetente, { text: "Pokemon nao encontrado!" }, { quoted: msg })
      } else {
        poke = POKEMONS_LISTA[Math.floor(Math.random() * POKEMONS_LISTA.length)]
      }
      const agora = Date.now()
      spawns[jidReal] = { ...poke, iniciado: agora, expira: agora + 120000, grupo: jidReal, avisouFuga: false, forcado: true }
      dbSalvar("spawns.json", spawns)
      await sock.sendMessage(remetente, {
        image: { url: poke.foto },
        caption: "SPAWN FORCADO!\n" + poke.nome + "\nTipo: " + poke.tipo + "\nUse !capturar"
      })
      return
    }

    const cmd = getComando(cmdName.toLowerCase())
    if (!cmd) {
      const p = (isGrupo && confGrupo.multiprefixo && confGrupo.prefixo) ? confGrupo.prefixo : prefixoGlobal
      const parecidos = comandosParecidos(cmdName, 3)
      let lista = parecidos.length
        ? "\n" + parecidos.map((r, i) => (i + 1) + ". " + p + r.comando + " (" + r.porcentagem + "%)").join("\n")
        : ""
      const textoBase = lista
        ? "Nao viu!\nVoce digitou: " + texto + "\nTalvez quis dizer:" + lista
        : "Nao viu!\n" + texto + " nao existe!\nUse " + p + "menu"
      await sock.sendMessage(remetente, { text: textoBase }, { quoted: msg })
      return
    }

    // 🚔 CHECA SE TÁ PRESO
    try {
      const cidData = dbLer("cidade.json", { usuarios: {} })
      const numSender = soNumero(sender)
      const userCidade = cidData.usuarios?.[numSender]
      if (userCidade?.preso && userCidade.preso > Date.now()) {
        const tempoRestante = formatarTempo(userCidade.preso - Date.now())
        const permitidos = ["prefixo"]
        if (!permitidos.includes(cmdName.toLowerCase())) {
          await sock.sendMessage(remetente, {
            text: "🚔 *VOCÊ ESTÁ PRESO!*\n\n⏰ Tempo restante: *" + tempoRestante + "*\n\n🦅 _\"Pague sua pena.\"_"
          }, { quoted: msg })
          return
        }
      }
      if (userCidade?.preso && userCidade.preso <= Date.now()) {
        cidData.usuarios[numSender].preso = null
        dbSalvar("cidade.json", cidData)
      }
    } catch (_) {}

    let groupMetadata = null
    let isAdmin = false
    if (isGrupo) {
      groupMetadata = await sock.groupMetadata(remetente)
      const p = groupMetadata.participants.find(x =>
        x.id === sender || soNumero(x.id) === soNumero(sender) || soNumero(x.lid) === soNumero(sender)
      )
      isAdmin = p?.admin === "admin" || p?.admin === "superadmin"
    }

    const ehSub = isGrupo && ehSubAdmin(remetente, sender)
    const permitidoSub = ["mute", "desmute", "ban", "kick", "link", "linkgp", "fechar", "closenow", "abrir", "opennow"]
    const ehComandoSub = permitidoSub.includes(cmd.nome) || (cmd.aliases || []).some(a => permitidoSub.includes(a))
    const podeAdmin = isAdmin || isDono || isSubDono || (ehSub && ehComandoSub)

    if (cfgGlobal.slow && !isDono && !isSubDono) {
      await new Promise(r => setTimeout(r, 2500))
    }

    if (cmd.categoria === "menu-rpg" && isGrupo) {
      const excecoes = ["rpg", "menurpg", "prefixo", "pokemon"]
      if (!excecoes.includes(cmd.nome) && confGrupo.rpgAtivo !== true) {
        return sock.sendMessage(remetente, {
          text: "RPG OFF! Ative com !rpg on"
        }, { quoted: msg })
      }
    }

    if (cmd.donoOnly && !isDono && !isSubDono) {
      return sock.sendMessage(remetente, { text: "Esse comando e so do imperador!" }, { quoted: msg })
    }
    if (cmd.adminOnly && !podeAdmin && !isSubDono) {
      return sock.sendMessage(remetente, { text: "Esse comando e de general!" }, { quoted: msg })
    }
    if (cmd.grupoOnly && !isGrupo) {
      return sock.sendMessage(remetente, { text: "So em grupo!" }, { quoted: msg })
    }

    try {
      await cmd.executar({
        sock, msg, args,
        sender, isGrupo, isAdmin, isDono, isSubDono,
        ehSub, podeAdmin,
        groupMetadata, config, prefixoAtivo: prefixoUsado || prefixoGlobal,
        db,
        utils: {
          getAlvo, soNumero, getTexto, downloadMediaMessage, recarregarCanal,
          naListaNegra, aluguelAtivo, grupoTemAluguel, formatarTempo,
          adicionarAviso, limparAvisos, DATA_DIR, botEhAdmin,
          dbLer, dbSalvar, getTextoBotao, ehSubAdmin
        }
      })
    } catch (e) {
      console.log("ERRO em " + cmd.nome + ":")
      console.log(e)
      try {
        await sock.sendMessage(remetente, {
          text: "ERRO no comando " + cmd.nome + "\n\n" + e.message
        }, { quoted: msg })
      } catch (_) {}
    }
  })

  sock.ev.on("group-participants.update", async (ev) => {
    try {
      const { id, participants, action, author } = ev
      const conf = db.grupos()[id] || {}

      function normalizar(p) {
        if (!p) return null
        if (typeof p === "string") return { jidReal: p.endsWith("@lid") ? null : p, melhor: p, num: soNumero(p) }
        if (typeof p === "object") {
          const jidReal = p.phoneNumber || (p.id && !p.id.endsWith("@lid") ? p.id : null)
          const lid = p.id && p.id.endsWith("@lid") ? p.id : null
          const melhor = jidReal || lid || p.id || p.phoneNumber
          return { jidReal, melhor, num: soNumero(melhor) }
        }
        return null
      }

      if (author && conf.x9) {
        for (const p of participants) {
          const info = normalizar(p)
          if (!info) continue
          if (action === "promote") await notificarX9(sock, id, "PROMOTE", author, info.melhor)
          else if (action === "demote") await notificarX9(sock, id, "DEMOTE", author, info.melhor)
          else if (action === "remove") await notificarX9(sock, id, "REMOVE", author, info.melhor)
        }
      }

      if (action === "add") {
        for (const p of participants) {
          const info = normalizar(p)
          if (!info) continue
          if (naListaNegra(id, info.jidReal || info.melhor)) {
            try { await sock.groupParticipantsUpdate(id, [info.melhor], "remove") } catch (_) {}
          }
        }
      }

      if (!conf.bemvindo) return
      const aplicar = (t, num, fb) => (t && t.trim() ? t : fb).replace(/%nmr%/g, "@" + num).replace(/#numero/g, "@" + num)

      if (action === "add") {
        for (const p of participants) {
          const info = normalizar(p)
          if (!info) continue
          if (naListaNegra(id, info.jidReal || info.melhor)) continue
          const txt = aplicar(conf.textobv, info.num, "Bem-vindo(a) @" + info.num + "!")
          try {
            if (conf.fundobv) await sock.sendMessage(id, { image: Buffer.from(conf.fundobv, "base64"), caption: txt, mentions: [info.melhor] })
            else await sock.sendMessage(id, { text: txt, mentions: [info.melhor] })
          } catch (_) {}
        }
      }

      if (action === "remove") {
        for (const p of participants) {
          const info = normalizar(p)
          if (!info) continue
          const txt = aplicar(conf.legendasaiu, info.num, "Ate logo @" + info.num + "!")
          try {
            if (conf.fundosaiu) await sock.sendMessage(id, { image: Buffer.from(conf.fundosaiu, "base64"), caption: txt, mentions: [info.melhor] })
            else await sock.sendMessage(id, { text: txt, mentions: [info.melhor] })
          } catch (_) {}
        }
      }
    } catch (e) { console.log("Erro participants:", e.message) }
  })
}

// ============================================================
// ⏰ AGENDAMENTOS
// ============================================================
function checarAgendamentos() {
  setInterval(async () => {
    if (!sockGlobal) return

    const v = db.vips()
    let vipAlterou = false
    const agoraMs = Date.now()
    for (const [jidVip, info] of Object.entries(v.vips || {})) {
      if (info.expira !== "inf" && info.expira <= agoraMs) {
        delete v.vips[jidVip]
        vipAlterou = true
      }
    }
    if (vipAlterou) db.salvarVips(v)

    if (global.rendasAutomaticas?.length) {
      for (const fn of global.rendasAutomaticas) {
        try { await fn(sockGlobal, db) } catch (e) { console.log("Erro renda auto:", e.message) }
      }
    }

    try {
      const rpg = db.rpg()
      const agoraRoubo = Date.now()
      for (const [numDono, dono] of Object.entries(rpg.usuarios || {})) {
        if (dono.pet !== "raposa") continue
        if (dono.ultimoRoubo && (agoraRoubo - dono.ultimoRoubo) < 3 * 60 * 60 * 1000) continue
        if ((dono.fomePet || 0) >= 80) continue
        const possiveis = Object.entries(rpg.usuarios).filter(([n, u]) => n !== numDono && (u.moedas || 0) > 100)
        if (possiveis.length === 0) continue
        const [numVitima, vitima] = possiveis[Math.floor(Math.random() * possiveis.length)]
        const roubado = Math.floor(vitima.moedas * 0.10)
        if (roubado <= 0) continue
        rpg.usuarios[numVitima].moedas -= roubado
        rpg.usuarios[numDono].moedas = (dono.moedas || 0) + roubado
        rpg.usuarios[numDono].ultimoRoubo = agoraRoubo
        rpg.usuarios[numDono].fomePet = Math.min(100, (dono.fomePet || 0) + 20)
        db.salvarRpg(rpg)
        const grupos = db.grupos()
        const primeiroGrupo = Object.keys(grupos).find(j => j.endsWith("@g.us"))
        if (primeiroGrupo && sockGlobal) {
          await sockGlobal.sendMessage(primeiroGrupo, {
            text: "A raposa de @" + numDono + " roubou " + roubado + " gold de @" + numVitima,
            mentions: [numDono + "@s.whatsapp.net", numVitima + "@s.whatsapp.net"]
          })
        }
      }
    } catch (e) { console.log("Erro raposa:", e.message) }

    // 🏙️ RENDA CIDADE
    try {
      const cidData = dbLer("cidade.json", { usuarios: {}, casas: {}, predios: {} })
      const rpg = db.rpg()
      rpg.usuarios = rpg.usuarios || {}

      const INTERVALO = 60 * 60 * 1000
      if (!global._ultimaRendaCidade) global._ultimaRendaCidade = 0
      const agora2 = Date.now()

      if (agora2 - global._ultimaRendaCidade >= INTERVALO) {
        global._ultimaRendaCidade = agora2
        let alterouCidade = false

        for (const [num, user] of Object.entries(cidData.usuarios || {})) {
          let rendaTotal = 0

          if (user.casa && cidData.casas?.[user.casa]) {
            const casa = cidData.casas[user.casa]
            const sujeira = user.sujeiraCasa || 0
            rendaTotal += casa.renda - Math.floor(casa.renda * (sujeira / 100))
            cidData.usuarios[num].sujeiraCasa = Math.min(100, (user.sujeiraCasa || 0) + 10)
            alterouCidade = true
          }

          if (user.predio && cidData.predios?.[user.predio]) {
            const predio = cidData.predios[user.predio]
            const sujeira = user.sujeiraPredio || 0
            rendaTotal += predio.renda - Math.floor(predio.renda * (sujeira / 100))
            cidData.usuarios[num].sujeiraPredio = Math.min(100, (user.sujeiraPredio || 0) + 10)
            alterouCidade = true
          }

          if (rendaTotal > 0) {
            rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
            rpg.usuarios[num].moedas = (rpg.usuarios[num].moedas || 0) + rendaTotal
          }
        }

        if (alterouCidade) dbSalvar("cidade.json", cidData)
        db.salvarRpg(rpg)
      }
    } catch (e) { console.log("Erro renda cidade:", e.message) }

    try {
      const agoraSpawn = Date.now()
      const grupos = db.grupos()
      const spawns = dbLer("spawns.json", {})
      for (const jid of Object.keys(grupos)) {
        if (!jid.endsWith("@g.us")) continue
        const conf = grupos[jid]
        if (conf.pokemonAtivo !== true) continue
        if (conf.rpgAtivo !== true) continue
        const jidReal = jid.split(":")[0]
        const atual = spawns[jidReal] || spawns[jid]
        if (atual && agoraSpawn >= atual.expira && !atual.avisouFuga) {
          if (sockGlobal) {
            try {
              await sockGlobal.sendMessage(jid, {
                image: { url: atual.foto },
                caption: "Fugiu! " + atual.nome + " - Tipo: " + atual.tipo
              })
            } catch (_) {}
          }
          spawns[jidReal] = atual
          spawns[jidReal].avisouFuga = true
          spawns[jidReal].iniciado = agoraSpawn
          dbSalvar("spawns.json", spawns)
          continue
        }
        if (atual && agoraSpawn < atual.expira) continue
        if (atual && atual.avisouFuga && (agoraSpawn - atual.iniciado) < 4 * 60 * 1000) continue
        const poke = sortearPokemon()
        spawns[jidReal] = { ...poke, iniciado: agoraSpawn, expira: agoraSpawn + 60000, grupo: jidReal, avisouFuga: false }
        dbSalvar("spawns.json", spawns)
        if (sockGlobal) {
          try {
            await sockGlobal.sendMessage(jid, {
              image: { url: poke.foto },
              caption: "Pokemon selvagem! " + poke.nome + " - Tipo: " + poke.tipo + "\nUse !capturar"
            })
          } catch (_) {}
        }
      }
    } catch (e) { console.log("Erro spawn:", e.message) }

    const agora = new Date()
    const horaAtual = String(agora.getHours()).padStart(2, "0") + ":" + String(agora.getMinutes()).padStart(2, "0")
    const dataHoje = agora.toISOString().slice(0, 10)
    const grupos = db.grupos()
    let alterou = false
    for (const [jid, conf] of Object.entries(grupos)) {
      if (!jid.endsWith("@g.us")) continue
      if (conf.abrirHora === horaAtual && conf.ultimoAbrir !== dataHoje) {
        try {
          await sockGlobal.groupSettingUpdate(jid, "not_announcement")
          const legenda = conf.legendaAbrir?.trim() || "Territorio aberto!"
          if (conf.fotoAbrir) await sockGlobal.sendMessage(jid, { image: Buffer.from(conf.fotoAbrir, "base64"), caption: legenda })
          else await sockGlobal.sendMessage(jid, { text: legenda })
          conf.ultimoAbrir = dataHoje; alterou = true
        } catch (e) {}
      }
      if (conf.fecharHora === horaAtual && conf.ultimoFechar !== dataHoje) {
        try {
          await sockGlobal.groupSettingUpdate(jid, "announcement")
          const legenda = conf.legendaFechar?.trim() || "Territorio fechado!"
          if (conf.fotoFechar) await sockGlobal.sendMessage(jid, { image: Buffer.from(conf.fotoFechar, "base64"), caption: legenda })
          else await sockGlobal.sendMessage(jid, { text: legenda })
          conf.ultimoFechar = dataHoje; alterou = true
        } catch (e) {}
      }
    }
    if (alterou) db.salvarGrupos(grupos)
  }, 30000)
}

// ============================================================
// 💻 CONSOLE
// ============================================================
function iniciarConsole() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, prompt: "napoleao> " })
  rl.prompt()
  rl.on("line", async (linha) => {
    const texto = linha.trim()
    const [cmd, ...args] = texto.split(/\s+/)
    const c = (cmd || "").toLowerCase()
    if (!c) { rl.prompt(); return }
    if (c === "saida" || c === "exit") process.exit(0)
    if (c === "canal") {
      const sub = (args[0] || "").toLowerCase()
      if (sub === "ver") {
        const c1 = db.canal()
        console.log(c1?.jid ? "\n" + c1.nome + " | " + c1.link + "\n" : "\nNenhum canal.\n")
        rl.prompt(); return
      }
      if (sub === "0" || sub === "off") {
        db.salvarCanal({ jid: null, nome: null, link: null })
        recarregarCanal()
        console.log("\nDesativado!\n"); rl.prompt(); return
      }
      if (sub.startsWith("http")) { await salvarCanalPeloLink(sub); rl.prompt(); return }
      rl.question("Link (ou 0): ", async (l) => {
        l = (l || "").trim()
        if (l === "0" || !l) { rl.prompt(); return }
        await salvarCanalPeloLink(l); rl.prompt()
      })
      return
    }
    if (c === "reload") {
      comandos.clear()
      aliases.clear()
      global.rendasAutomaticas = []
      carregarMenus()
      console.log("Menus recarregados!\n")
      rl.prompt(); return
    }
    rl.prompt()
  })
}

async function salvarCanalPeloLink(link) {
  const codigo = String(link).replace(/.*whatsapp\.com\/channel\//, "").replace(/.*wa\.me\/channel\//, "").split(/[\/?\s]/)[0]
  if (!codigo || !sockGlobal) return
  try {
    const meta = await sockGlobal.newsletterMetadata("invite", codigo)
    const jidReal = meta?.jid || meta?.id
    if (!jidReal) throw new Error("Canal nao encontrado")
    db.salvarCanal({ jid: jidReal, nome: meta?.name || "Canal", link: "https://whatsapp.com/channel/" + codigo })
    recarregarCanal()
    console.log("\nCanal salvo!\n")
  } catch (e) { console.log(e.message + "\n") }
}

// ============================================================
// 🚀 START
// ============================================================
carregarMenus()
iniciar()
iniciarConsole()
checarAgendamentos()