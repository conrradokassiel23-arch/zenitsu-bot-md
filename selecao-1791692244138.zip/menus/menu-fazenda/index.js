/* ============================================================
   🌾 MENU FAZENDA - NAPOLEÃO BONAPARTE
   ============================================================ */

const fs = require("fs")
const path = require("path")

const DATA_DIR = path.join(__dirname, "..", "..", "data")

function dbLer(arquivo, padrao = {}) {
  const p = path.join(DATA_DIR, arquivo)
  if (!fs.existsSync(p)) {
    fs.writeFileSync(p, JSON.stringify(padrao, null, 2))
    return padrao
  }
  try { return JSON.parse(fs.readFileSync(p, "utf8")) } catch { return padrao }
}

function dbSalvar(arquivo, dados) {
  fs.writeFileSync(path.join(DATA_DIR, arquivo), JSON.stringify(dados, null, 2))
}

function normalizar(s) {
  return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim()
}

const INTERVALO_RENDA = 3 * 60 * 60 * 1000
const MAX_UPGRADES = 10
const CAP_BASE = 3
const CAP_UPGRADE = 3
const PRECO_CERCADO = 500
const PRECO_ALIMENTAR = 300
const PRECO_BANHO = 200
const PRECO_TERRA = 800
const PRECO_AGUA = 50
const AGUA_POR_REGA = 1

// ============ ANIMAIS ============
const ANIMAIS = [
  { id: "galinha", nome: "Galinha", emoji: "🐔", preco: 100, producao: 15 },
  { id: "galo", nome: "Galo", emoji: "🐓", preco: 120, producao: 18 },
  { id: "pato", nome: "Pato", emoji: "🦆", preco: 150, producao: 22 },
  { id: "ganso", nome: "Ganso", emoji: "🦢", preco: 180, producao: 25 },
  { id: "peru", nome: "Peru", emoji: "🦃", preco: 200, producao: 28 },
  { id: "marreco", nome: "Marreco", emoji: "🦆", preco: 140, producao: 20 },
  { id: "codorna", nome: "Codorna", emoji: "🐦", preco: 90, producao: 12 },
  { id: "faisao", nome: "Faisão", emoji: "🦜", preco: 220, producao: 30 },
  { id: "pavao", nome: "Pavão", emoji: "🦚", preco: 500, producao: 60 },
  { id: "cisne", nome: "Cisne", emoji: "🦢", preco: 450, producao: 55 },
  { id: "avestruz", nome: "Avestruz", emoji: "🦤", preco: 800, producao: 100 },
  { id: "ema", nome: "Ema", emoji: "🦤", preco: 700, producao: 90 },
  { id: "coelho", nome: "Coelho", emoji: "🐰", preco: 120, producao: 18 },
  { id: "coelha", nome: "Coelha", emoji: "🐇", preco: 130, producao: 20 },
  { id: "hamster", nome: "Hamster", emoji: "🐹", preco: 80, producao: 10 },
  { id: "porquinhodaIndia", nome: "Porquinho da Índia", emoji: "🐹", preco: 90, producao: 12 },
  { id: "chinchila", nome: "Chinchila", emoji: "🐭", preco: 200, producao: 25 },
  { id: "furao", nome: "Furão", emoji: "🦡", preco: 250, producao: 30 },
  { id: "ratoBranco", nome: "Rato Branco", emoji: "🐭", preco: 60, producao: 8 },
  { id: "minhoca", nome: "Minhoca", emoji: "🪱", preco: 50, producao: 8 },
  { id: "vaca", nome: "Vaca", emoji: "🐮", preco: 500, producao: 65 },
  { id: "boi", nome: "Boi", emoji: "🐂", preco: 700, producao: 85 },
  { id: "vacaLeiteira", nome: "Vaca Leiteira", emoji: "🐄", preco: 800, producao: 100 },
  { id: "touro", nome: "Touro", emoji: "🐂", preco: 900, producao: 110 },
  { id: "bufalo", nome: "Búfalo", emoji: "🐃", preco: 1000, producao: 120 },
  { id: "bufala", nome: "Búfala", emoji: "🐃", preco: 950, producao: 115 },
  { id: "porco", nome: "Porco", emoji: "🐷", preco: 400, producao: 50 },
  { id: "javali", nome: "Javali", emoji: "🐗", preco: 600, producao: 75 },
  { id: "cabra", nome: "Cabra", emoji: "🐐", preco: 350, producao: 45 },
  { id: "bode", nome: "Bode", emoji: "🐐", preco: 380, producao: 48 },
  { id: "ovelha", nome: "Ovelha", emoji: "🐑", preco: 400, producao: 52 },
  { id: "carneiro", nome: "Carneiro", emoji: "🐏", preco: 450, producao: 58 },
  { id: "ovelhaNegra", nome: "Ovelha Negra", emoji: "🐑", preco: 500, producao: 62 },
  { id: "cordeiro", nome: "Cordeiro", emoji: "🐑", preco: 300, producao: 40 },
  { id: "cavalo", nome: "Cavalo", emoji: "🐴", preco: 900, producao: 100 },
  { id: "egua", nome: "Égua", emoji: "🐴", preco: 850, producao: 95 },
  { id: "potro", nome: "Potro", emoji: "🐎", preco: 600, producao: 70 },
  { id: "ponei", nome: "Pônei", emoji: "🐴", preco: 400, producao: 50 },
  { id: "burro", nome: "Burro", emoji: "🫏", preco: 350, producao: 45 },
  { id: "mula", nome: "Mula", emoji: "🫏", preco: 380, producao: 48 },
  { id: "jumento", nome: "Jumento", emoji: "🫏", preco: 320, producao: 42 },
  { id: "lhama", nome: "Lhama", emoji: "🦙", preco: 700, producao: 85 },
  { id: "alpaca", nome: "Alpaca", emoji: "🦙", preco: 750, producao: 90 },
  { id: "cachorroPastor", nome: "Cachorro Pastor", emoji: "🐕", preco: 400, producao: 50 },
  { id: "cachorroFila", nome: "Cachorro Fila", emoji: "🐕‍🦺", preco: 500, producao: 60 },
  { id: "gato", nome: "Gato", emoji: "🐱", preco: 300, producao: 40 },
  { id: "gata", nome: "Gata", emoji: "🐈", preco: 320, producao: 42 },
  { id: "tartaruga", nome: "Tartaruga", emoji: "🐢", preco: 250, producao: 30 },
  { id: "cagado", nome: "Cágado", emoji: "🐢", preco: 220, producao: 28 },
  { id: "ra", nome: "Rã", emoji: "🐸", preco: 100, producao: 15 },
  { id: "sapo", nome: "Sapo", emoji: "🐸", preco: 120, producao: 18 },
  { id: "abelha", nome: "Abelha (Colmeia)", emoji: "🐝", preco: 300, producao: 60 },
  { id: "tilapia", nome: "Tilápia", emoji: "🐟", preco: 150, producao: 25 },
  { id: "carpa", nome: "Carpa", emoji: "🐠", preco: 200, producao: 30 },
  { id: "truta", nome: "Truta", emoji: "🐟", preco: 250, producao: 35 },
  { id: "bagre", nome: "Bagre", emoji: "🐟", preco: 180, producao: 28 },
  { id: "pintado", nome: "Pintado", emoji: "🐟", preco: 300, producao: 45 }
]

// ============ SEMENTES ============
const SEMENTES = [
  { id: "milho", nome: "Milho", emoji: "🌽", preco: 30, vendaBase: 90, tempo: 20 },
  { id: "trigo", nome: "Trigo", emoji: "🌾", preco: 25, vendaBase: 75, tempo: 18 },
  { id: "arroz", nome: "Arroz", emoji: "🍚", preco: 35, vendaBase: 100, tempo: 22 },
  { id: "feijao", nome: "Feijão", emoji: "🫘", preco: 28, vendaBase: 85, tempo: 20 },
  { id: "soja", nome: "Soja", emoji: "🫘", preco: 40, vendaBase: 120, tempo: 25 },
  { id: "cevada", nome: "Cevada", emoji: "🌾", preco: 27, vendaBase: 80, tempo: 18 },
  { id: "centeio", nome: "Centeio", emoji: "🌾", preco: 26, vendaBase: 78, tempo: 19 },
  { id: "aveia", nome: "Aveia", emoji: "🌾", preco: 24, vendaBase: 72, tempo: 17 },
  { id: "sorgo", nome: "Sorgo", emoji: "🌾", preco: 30, vendaBase: 88, tempo: 21 },
  { id: "girassol", nome: "Girassol", emoji: "🌻", preco: 45, vendaBase: 130, tempo: 28 },
  { id: "canola", nome: "Canola", emoji: "🌼", preco: 42, vendaBase: 125, tempo: 26 },
  { id: "algodao", nome: "Algodão", emoji: "🌸", preco: 55, vendaBase: 160, tempo: 35 },
  { id: "cana", nome: "Cana-de-açúcar", emoji: "🎋", preco: 60, vendaBase: 180, tempo: 40 },
  { id: "beterraba", nome: "Beterraba", emoji: "🍠", preco: 32, vendaBase: 95, tempo: 22 },
  { id: "batata", nome: "Batata", emoji: "🥔", preco: 30, vendaBase: 90, tempo: 20 },
  { id: "batataDoce", nome: "Batata-doce", emoji: "🍠", preco: 34, vendaBase: 100, tempo: 22 },
  { id: "mandioca", nome: "Mandioca", emoji: "🥔", preco: 36, vendaBase: 105, tempo: 24 },
  { id: "cenoura", nome: "Cenoura", emoji: "🥕", preco: 28, vendaBase: 82, tempo: 19 },
  { id: "rabanete", nome: "Rabanete", emoji: "🥬", preco: 22, vendaBase: 65, tempo: 15 },
  { id: "nabo", nome: "Nabo", emoji: "🥬", preco: 24, vendaBase: 70, tempo: 16 },
  { id: "cebola", nome: "Cebola", emoji: "🧅", preco: 30, vendaBase: 88, tempo: 21 },
  { id: "alho", nome: "Alho", emoji: "🧄", preco: 35, vendaBase: 102, tempo: 23 },
  { id: "tomate", nome: "Tomate", emoji: "🍅", preco: 40, vendaBase: 118, tempo: 25 },
  { id: "pimentao", nome: "Pimentão", emoji: "🫑", preco: 38, vendaBase: 112, tempo: 24 },
  { id: "pepino", nome: "Pepino", emoji: "🥒", preco: 32, vendaBase: 95, tempo: 20 },
  { id: "abobrinha", nome: "Abobrinha", emoji: "🥒", preco: 34, vendaBase: 100, tempo: 22 },
  { id: "abobora", nome: "Abóbora", emoji: "🎃", preco: 50, vendaBase: 150, tempo: 30 },
  { id: "melancia", nome: "Melancia", emoji: "🍉", preco: 65, vendaBase: 195, tempo: 40 },
  { id: "melao", nome: "Melão", emoji: "🍈", preco: 60, vendaBase: 180, tempo: 38 },
  { id: "morango", nome: "Morango", emoji: "🍓", preco: 70, vendaBase: 210, tempo: 32 },
  { id: "uva", nome: "Uva", emoji: "🍇", preco: 80, vendaBase: 240, tempo: 45 },
  { id: "maca", nome: "Maçã", emoji: "🍎", preco: 75, vendaBase: 225, tempo: 42 },
  { id: "laranja", nome: "Laranja", emoji: "🍊", preco: 70, vendaBase: 210, tempo: 40 },
  { id: "limao", nome: "Limão", emoji: "🍋", preco: 55, vendaBase: 165, tempo: 32 },
  { id: "banana", nome: "Banana", emoji: "🍌", preco: 60, vendaBase: 180, tempo: 35 },
  { id: "abacaxi", nome: "Abacaxi", emoji: "🍍", preco: 85, vendaBase: 255, tempo: 45 },
  { id: "manga", nome: "Manga", emoji: "🥭", preco: 80, vendaBase: 240, tempo: 42 },
  { id: "coco", nome: "Coco", emoji: "🥥", preco: 90, vendaBase: 270, tempo: 48 },
  { id: "amendoim", nome: "Amendoim", emoji: "🥜", preco: 45, vendaBase: 135, tempo: 28 },
  { id: "cafe", nome: "Café", emoji: "☕", preco: 100, vendaBase: 300, tempo: 50 },
  { id: "cacau", nome: "Cacau", emoji: "🍫", preco: 110, vendaBase: 330, tempo: 52 },
  { id: "cha", nome: "Chá", emoji: "🍵", preco: 50, vendaBase: 150, tempo: 30 },
  { id: "ervaMate", nome: "Erva-mate", emoji: "🍃", preco: 55, vendaBase: 165, tempo: 32 },
  { id: "alfafa", nome: "Alfafa", emoji: "🌿", preco: 30, vendaBase: 90, tempo: 20 },
  { id: "cogumelo", nome: "Cogumelo", emoji: "🍄", preco: 65, vendaBase: 195, tempo: 35 },
  { id: "alface", nome: "Alface", emoji: "🥬", preco: 20, vendaBase: 60, tempo: 14 },
  { id: "couve", nome: "Couve", emoji: "🥬", preco: 22, vendaBase: 65, tempo: 15 },
  { id: "brocolis", nome: "Brócolis", emoji: "🥦", preco: 28, vendaBase: 85, tempo: 20 },
  { id: "repolho", nome: "Repolho", emoji: "🥬", preco: 26, vendaBase: 80, tempo: 18 },
  { id: "espinafre", nome: "Espinafre", emoji: "🥬", preco: 24, vendaBase: 72, tempo: 16 }
]

function acharAnimal(nome) {
  const n = normalizar(nome)
  return ANIMAIS.find(a => normalizar(a.nome) === n) || ANIMAIS.find(a => a.id === n) || ANIMAIS.find(a => normalizar(a.nome).includes(n))
}

function acharSemente(nome) {
  const n = normalizar(nome)
  return SEMENTES.find(s => normalizar(s.nome) === n) || SEMENTES.find(s => s.id === n) || SEMENTES.find(s => normalizar(s.nome).includes(n))
}

function getFazenda(num) {
  const f = dbLer("fazenda.json", { usuarios: {} })
  f.usuarios = f.usuarios || {}
  f.usuarios[num] = f.usuarios[num] || {
    cercados: 0, limiteAnimais: 0, upgrades: 0, animais: [],
    sujeira: 0, ultimaRenda: Date.now(), rendaTotal: 0,
    rendaPendente: 0,
    terras: 0, agua: 0, sementes: {}, plantacoes: []
  }
  const u = f.usuarios[num]
  u.terras = u.terras || 0
  u.agua = u.agua || 0
  u.sementes = u.sementes || {}
  u.plantacoes = u.plantacoes || []
  u.rendaPendente = u.rendaPendente || 0
  return { f, u }
}

function calcularRenda(user) {
  if (!user.animais || !user.animais.length) return 0
  let renda = 0
  for (const a of user.animais) {
    const info = ANIMAIS.find(x => x.id === a.id)
    if (!info) continue
    let prod = info.producao
    prod *= (1 - Math.min(a.fome || 0, 100) / 200)
    prod *= (1 - Math.min(a.sujo || 0, 100) / 200)
    renda += prod
  }
  renda *= (1 - Math.min(user.sujeira || 0, 100) / 200)
  renda *= (1 + (user.upgrades || 0) * 0.05)
  return Math.floor(renda)
}

function nivelFazenda(user) {
  const total = user.limiteAnimais || 0
  if (total === 0) return 0
  return Math.floor(total / CAP_UPGRADE)
}

function qualidadePlanta(p) {
  const regas = p.regas || 0
  return Math.min(100, Math.floor(regas * 15 + (p.qualidadeBase || 50)))
}

function valorPlanta(p) {
  const s = SEMENTES.find(x => x.id === p.id)
  if (!s) return 0
  const q = qualidadePlanta(p)
  return Math.floor(s.vendaBase * (0.5 + q / 100))
}

module.exports = {
  menu: "menu-fazenda",
  grupoOnly: false,
  adminOnly: false,
  donoOnly: false,

  async rendaAutomatica(sock, db) {
    const f = dbLer("fazenda.json", { usuarios: {} })
    let alterou = false
    const agora = Date.now()

    for (const [num, user] of Object.entries(f.usuarios || {})) {
      if (user.plantacoes) {
        for (const p of user.plantacoes) {
          if (p.pronta) continue
          const s = SEMENTES.find(x => x.id === p.id)
          if (!s) continue
          const tempoNecessario = s.tempo * 60 * 1000
          const regasBonus = (p.regas || 0) * 2 * 60 * 1000
          const tempoFinal = Math.max(5 * 60 * 1000, tempoNecessario - regasBonus)
          if (agora - p.plantadaEm >= tempoFinal) {
            p.pronta = true
            p.prontaEm = agora
            alterou = true
          }
        }
      }

      if (!user.animais || !user.animais.length) continue
      if (agora - (user.ultimaRenda || 0) < INTERVALO_RENDA) continue

      const renda = calcularRenda(user)
      user.rendaPendente = (user.rendaPendente || 0) + renda
      user.rendaTotal = (user.rendaTotal || 0) + renda

      for (const a of user.animais) {
        a.fome = Math.min(100, (a.fome || 0) + 20)
        a.sujo = Math.min(100, (a.sujo || 0) + 15)
      }
      user.sujeira = Math.min(100, (user.sujeira || 0) + 20)
      user.ultimaRenda = agora
      alterou = true

      try {
        const grupos = db.grupos()
        const grupo = Object.keys(grupos).find(j => j.endsWith("@g.us"))
        if (grupo) {
          await sock.sendMessage(grupo, {
            text: `🎩🌾 *RENDA ACUMULADA*\n\n👤 Usuário: *${num}*\n🦅 Acumulou: *+${renda} gold*\n🎩 Total pendente: *${user.rendaPendente}*\n🦅 Use *!resgatarfazenda* pra receber!`
          })
        }
      } catch (_) {}
    }
    if (alterou) dbSalvar("fazenda.json", f)
  },

  commands: {

    // ============ MENU FAZENDA ============
    menufazenda: {
      aliases: ["fazenda", "menuf", "comandosfazenda"],
      async executar({ sock, msg, prefixoAtivo, db }) {
        const jid = msg.key.remoteJid
        const p = prefixoAtivo
        const cfg = db.config()
        const texto =
`╭━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃   🎩🌾  𝐌𝐄𝐍𝐔 𝐅𝐀𝐙𝐄𝐍𝐃𝐀  🌾🎩   ┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

🦅 *Napoleão apresenta:*
🎩 *o celeiro imperial!*

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩💰 *RESGATAR*
▸ ${p}resgatarfazenda

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩🐾 *ANIMAIS*
▸ ${p}animais
▸ ${p}compraranimal <nome>
▸ ${p}venderanimal <nome>
▸ ${p}statusanimais

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩🌱 *SEMENTES / PLANTAÇÃO*
▸ ${p}sementes
▸ ${p}comprarsemente <nome>
▸ ${p}plantarsemente <nome>
▸ ${p}regarsementes
▸ ${p}regarplanta <nome>
▸ ${p}venderplanta <nome>

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩🏠 *CERCAS / TERRAS*
▸ ${p}comprarcercado
▸ ${p}comprarterra
▸ ${p}compraragua

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩🍖 *CUIDADOS*
▸ ${p}alimentaranimais (300$)
▸ ${p}banhoanimais (200$)
▸ ${p}limparfazenda

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩📊 *STATUS*
▸ ${p}statusfazenda
▸ ${p}statusplanta

━━━━━━━━━━━━━━━━━━━━━━━━━

🦅 *Renda acumula de 3h em 3h!*
🎩 Use *!resgatarfazenda* pra receber~`

        if (cfg.fotoMenu) {
          const buf = Buffer.from(cfg.fotoMenu, "base64")
          if (cfg.tipoMenu === "video") return sock.sendMessage(jid, { video: buf, mimetype: "video/mp4", fileName: "napoleao.mp4", gifPlayback: true, caption: texto }, { quoted: msg })
          return sock.sendMessage(jid, { image: buf, caption: texto }, { quoted: msg })
        }
        await sock.sendMessage(jid, { text: texto }, { quoted: msg })
      }
    },

    // ============ RESGATAR FAZENDA ============
    resgatarfazenda: {
      aliases: ["resgatar", "coletar", "coletarfazenda"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)

        const pendente = u.rendaPendente || 0
        if (pendente <= 0) {
          return sock.sendMessage(jid, {
            text: `🎩🌾 *RESGATAR FAZENDA*\n\n😢 Você não tem nada pra resgatar!\n\n🦅 A renda acumula a cada *3h*~\n🎩 Cuide dos bichinhos!`
          }, { quoted: msg })
        }

        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        rpg.usuarios[num].moedas = (rpg.usuarios[num].moedas || 0) + pendente
        db.salvarRpg(rpg)

        u.rendaPendente = 0
        dbSalvar("fazenda.json", f)

        const numLimpo = String(num).replace(/\D/g, "")
        await sock.sendMessage(jid, {
          text: `╭━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃   🎩💰 𝐑𝐄𝐒𝐆𝐀𝐓𝐄 𝐅𝐄𝐈𝐓𝐎 💰🎩  ┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━╯

🦅👤 @${numLimpo}
🎩💰 Resgatou: *+${pendente} gold*
🦅💼 Saldo total: *${rpg.usuarios[num].moedas}*

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩🌾 Cuide bem da fazenda!\n🦅 Volte em *3h*~`,
          mentions: [`${numLimpo}@s.whatsapp.net`]
        }, { quoted: msg })
      }
    },

    // ============ ANIMAIS ============
    animais: {
      aliases: ["listaanimais", "lojaanimais"],
      async executar({ sock, msg, prefixoAtivo }) {
        const jid = msg.key.remoteJid
        const p = prefixoAtivo
        let txt = `🎩🐾 *ANIMAIS DISPONÍVEIS* 🐾🎩\n\n`
        ANIMAIS.forEach((a, i) => {
          txt += `🎩 ${i + 1}. ${a.emoji} *${a.nome}*\n   💰 ${a.preco} | 📈 ${a.producao}/3h\n`
        })
        txt += `\n🦅💡 Use: *${p}compraranimal <nome>*`
        await sock.sendMessage(jid, { text: txt }, { quoted: msg })
      }
    },

    comprarcercado: {
      aliases: ["cercado", "buycercado"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)

        if (u.upgrades >= MAX_UPGRADES) return sock.sendMessage(jid, { text: `🎩💢 Máximo de cercados (${MAX_UPGRADES})!` }, { quoted: msg })
        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        const gold = rpg.usuarios[num].moedas || 0
        const preco = u.upgrades === 0 ? 0 : PRECO_CERCADO
        if (gold < preco) return sock.sendMessage(jid, { text: `🎩💢 Faltam *${preco - gold}* gold!` }, { quoted: msg })

        rpg.usuarios[num].moedas = gold - preco
        u.upgrades += 1; u.cercados += 1
        u.limiteAnimais = CAP_BASE + (u.upgrades - 1) * CAP_UPGRADE
        db.salvarRpg(rpg); dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, { text: `🎩✅ Cercado comprado!\n🐾 Capacidade: *${u.limiteAnimais}*\n📊 Upgrades: *${u.upgrades}/${MAX_UPGRADES}*`, mentions: [sender] }, { quoted: msg })
      }
    },

    compraranimal: {
      aliases: ["buyanimal", "adotaranimal"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)

        if (u.cercados === 0) return sock.sendMessage(jid, { text: `🎩💢 Compre um *cercado* primeiro!` }, { quoted: msg })
        if (u.animais.length >= u.limiteAnimais) return sock.sendMessage(jid, { text: `🎩💢 Cercado cheio! ${u.animais.length}/${u.limiteAnimais}` }, { quoted: msg })

        const animal = acharAnimal(args.join(" "))
        if (!animal) return sock.sendMessage(jid, { text: `🎩❌ Não achei! Veja *!animais*` }, { quoted: msg })

        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        if ((rpg.usuarios[num].moedas || 0) < animal.preco) return sock.sendMessage(jid, { text: `🎩💢 Faltam *${animal.preco - (rpg.usuarios[num].moedas || 0)}* gold!` }, { quoted: msg })

        rpg.usuarios[num].moedas -= animal.preco
        u.animais.push({ id: animal.id, nome: animal.nome, emoji: animal.emoji, fome: 0, sujo: 0, compradoEm: Date.now() })
        db.salvarRpg(rpg); dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, { text: `🎩${animal.emoji} *${animal.nome}* comprado!\n📈 ${animal.producao}/3h`, mentions: [sender] }, { quoted: msg })
      }
    },

    venderanimal: {
      aliases: ["vendaranimal", "sellanimal"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)
        const idx = u.animais.findIndex(a => normalizar(a.nome) === normalizar(args.join(" ")) || a.id === normalizar(args.join(" ")))
        if (idx === -1) return sock.sendMessage(jid, { text: `🎩❌ Você não tem esse animal!` }, { quoted: msg })

        const a = u.animais[idx]
        const info = ANIMAIS.find(x => x.id === a.id)
        const valor = Math.floor((info?.preco || 100) * 0.5)
        u.animais.splice(idx, 1)
        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        rpg.usuarios[num].moedas = (rpg.usuarios[num].moedas || 0) + valor
        db.salvarRpg(rpg); dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, { text: `🎩💰 ${a.emoji} *${a.nome}* vendido!\n💵 +${valor}`, mentions: [sender] }, { quoted: msg })
      }
    },

    alimentaranimais: {
      aliases: ["alimentaranimal", "feedanimais"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)
        if (!u.animais.length) return sock.sendMessage(jid, { text: `🎩🐾 Sem animais!` }, { quoted: msg })
        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        if ((rpg.usuarios[num].moedas || 0) < PRECO_ALIMENTAR) return sock.sendMessage(jid, { text: `🎩💰 Precisa de *${PRECO_ALIMENTAR}*!` }, { quoted: msg })
        rpg.usuarios[num].moedas -= PRECO_ALIMENTAR
        let n = 0
        for (const a of u.animais) { if ((a.fome || 0) > 0) { a.fome = 0; n++ } }
        db.salvarRpg(rpg); dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, { text: `🎩🍖 *${n}* animal(is) alimentados!\n💰 -${PRECO_ALIMENTAR}`, mentions: [sender] }, { quoted: msg })
      }
    },

    banhoanimais: {
      aliases: ["banhoanimal", "lavaranimais"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)
        if (!u.animais.length) return sock.sendMessage(jid, { text: `🎩🐾 Sem animais!` }, { quoted: msg })
        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        if ((rpg.usuarios[num].moedas || 0) < PRECO_BANHO) return sock.sendMessage(jid, { text: `🎩💰 Precisa de *${PRECO_BANHO}*!` }, { quoted: msg })
        rpg.usuarios[num].moedas -= PRECO_BANHO
        let n = 0
        for (const a of u.animais) { if ((a.sujo || 0) > 0) { a.sujo = 0; n++ } }
        db.salvarRpg(rpg); dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, { text: `🎩🚿 *${n}* animal(is) lavados!\n💰 -${PRECO_BANHO}`, mentions: [sender] }, { quoted: msg })
      }
    },

    limparfazenda: {
      aliases: ["limparfaz"],
      async executar({ sock, msg, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)
        if ((u.sujeira || 0) === 0) return sock.sendMessage(jid, { text: `🎩✨ Já está limpa!` }, { quoted: msg })
        u.sujeira = 0
        dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, { text: `🎩🧹 Fazenda limpa!`, mentions: [sender] }, { quoted: msg })
      }
    },

    statusfazenda: {
      aliases: ["fazendastatus", "minhafazenda"],
      async executar({ sock, msg, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { u } = getFazenda(num)
        if (u.cercados === 0 && u.terras === 0) return sock.sendMessage(jid, { text: `🎩🌾 Sem fazenda! Use *!comprarcercado*` }, { quoted: msg })

        const nivel = nivelFazenda(u)
        const renda = calcularRenda(u)
        const restante = Math.max(0, INTERVALO_RENDA - (Date.now() - (u.ultimaRenda || Date.now())))
        const h = Math.floor(restante / 3600000)
        const m = Math.floor((restante % 3600000) / 60000)
        const tempo = h > 0 ? `${h}h ${m}min` : `${m}min`
        const cheio = Math.min(10, Math.floor(u.animais.length / Math.max(1, u.limiteAnimais) * 10))
        const barra = "🟨".repeat(cheio) + "⬜".repeat(10 - cheio)
        const statusSujeira = u.sujeira > 70 ? "🔴" : u.sujeira > 40 ? "🟡" : "🟢"
        const prontas = (u.plantacoes || []).filter(p => p.pronta).length
        const numLimpo = String(num).replace(/\D/g, "")

        await sock.sendMessage(jid, {
          text: `╭━━━━━━━━━━━━━━━━━━━━━━━━━╮
┃  🎩🌾 𝐒𝐓𝐀𝐓𝐔𝐒 𝐅𝐀𝐙𝐄𝐍𝐃𝐀 🌾🎩 ┃
╰━━━━━━━━━━━━━━━━━━━━━━━━━╯

🦅👤 @${numLimpo}
🎩📊 Nível: *${nivel}*
🎩🏠 Cercados: *${u.cercados}*
🎩🟫 Terras: *${u.terras}*
🎩💧 Água: *${u.agua}L*
🎩🐾 Animais: *${barra} ${u.animais.length}/${u.limiteAnimais}*
🎩🌱 Plantações: *${u.plantacoes.length}* (${prontas} prontas)
🎩🧹 Sujeira: *${u.sujeira}%* ${statusSujeira}

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩💰 *RENDA*
▸ Rendimento: *${renda}/3h*
▸ 💰 Pendente: *${u.rendaPendente || 0}*
▸ ⏰ Próxima: *${tempo}*
▸ 💼 Total ganho: *${u.rendaTotal || 0}*
▸ 📈 Upgrade: *${u.upgrades}/${MAX_UPGRADES}*
━━━━━━━━━━━━━━━━━━━━━━━━━

🦅 Use *!resgatarfazenda* pra pegar!`,
          mentions: [`${numLimpo}@s.whatsapp.net`]
        }, { quoted: msg })
      }
    },

    statusanimais: {
      aliases: ["meusanimais", "veranimais"],
      async executar({ sock, msg, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { u } = getFazenda(num)
        if (!u.animais.length) return sock.sendMessage(jid, { text: `🎩🐾 Sem animais!` }, { quoted: msg })
        let txt = `🎩🐾 *ANIMAIS* (${u.animais.length}/${u.limiteAnimais})\n\n`
        for (const a of u.animais) {
          const fomeIco = a.fome > 70 ? "🔴" : a.fome > 40 ? "🟡" : "🟢"
          const sujoIco = a.sujo > 70 ? "🔴" : a.sujo > 40 ? "🟡" : "🟢"
          txt += `🎩 ${a.emoji} *${a.nome}*\n   🍖 ${fomeIco} ${a.fome}% | 🚿 ${sujoIco} ${a.sujo}%\n\n`
        }
        await sock.sendMessage(jid, { text: txt, mentions: [sender] }, { quoted: msg })
      }
    },

    // ============ SEMENTES ============
    sementes: {
      aliases: ["lojasementes", "listarsementes"],
      async executar({ sock, msg, prefixoAtivo }) {
        let txt = `🎩🌱 *LOJA DE SEMENTES* 🌱🎩\n\n`
        SEMENTES.forEach((s, i) => {
          txt += `🎩 ${i + 1}. ${s.emoji} *${s.nome}*\n   💰 ${s.preco} | ⏰ ${s.tempo}min | 💵 ~${s.vendaBase}\n`
        })
        txt += `\n🦅💡 *${prefixoAtivo}comprarsemente <nome> <qtd>*`
        await sock.sendMessage(msg.key.remoteJid, { text: txt }, { quoted: msg })
      }
    },

    comprarsemente: {
      aliases: ["buysemente"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)

        if (u.terras === 0) return sock.sendMessage(jid, { text: `🎩💢 Compre uma *terra* primeiro! Use *!comprarterra*` }, { quoted: msg })

        let qtd = 1
        const ultimo = args[args.length - 1]
        if (/^\d+$/.test(ultimo)) { qtd = parseInt(ultimo); args.pop() }

        const sem = acharSemente(args.join(" "))
        if (!sem) return sock.sendMessage(jid, { text: `🎩❌ Não achei! Veja *!sementes*` }, { quoted: msg })

        const total = sem.preco * qtd
        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        if ((rpg.usuarios[num].moedas || 0) < total) return sock.sendMessage(jid, { text: `🎩💢 Faltam *${total - (rpg.usuarios[num].moedas || 0)}* gold!` }, { quoted: msg })

        rpg.usuarios[num].moedas -= total
        u.sementes[sem.id] = (u.sementes[sem.id] || 0) + qtd
        db.salvarRpg(rpg); dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, { text: `🎩${sem.emoji} *${sem.nome}* x${qtd}!\n💰 -${total}`, mentions: [sender] }, { quoted: msg })
      }
    },

    comprarterra: {
      aliases: ["terra", "buyterra"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)

        if (u.terras >= 20) return sock.sendMessage(jid, { text: `🎩💢 Máximo de 20 terras!` }, { quoted: msg })

        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        const gold = rpg.usuarios[num].moedas || 0
        const preco = PRECO_TERRA + u.terras * 200
        if (gold < preco) return sock.sendMessage(jid, { text: `🎩💢 Faltam *${preco - gold}* gold!\n💰 Preço: *${preco}*` }, { quoted: msg })

        rpg.usuarios[num].moedas = gold - preco
        u.terras += 1
        db.salvarRpg(rpg); dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, { text: `🎩🟫 Terra comprada!\n📊 Total: *${u.terras}*\n💰 -${preco}`, mentions: [sender] }, { quoted: msg })
      }
    },

    compraragua: {
      aliases: ["agua", "buyagua"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)
        const qtd = parseInt(args[0]) || 10
        if (qtd < 1 || qtd > 100) return sock.sendMessage(jid, { text: `🎩💧 Use *!compraragua <1-100>*` }, { quoted: msg })

        const total = PRECO_AGUA * qtd
        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        if ((rpg.usuarios[num].moedas || 0) < total) return sock.sendMessage(jid, { text: `🎩💢 Faltam *${total - (rpg.usuarios[num].moedas || 0)}* gold!` }, { quoted: msg })

        rpg.usuarios[num].moedas -= total
        u.agua += qtd
        db.salvarRpg(rpg); dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, { text: `🎩💧 *${qtd}L* comprada!\n💼 Total: *${u.agua}L*\n💰 -${total}`, mentions: [sender] }, { quoted: msg })
      }
    },

    plantarsemente: {
      aliases: ["plantar", "plant"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)

        if (u.terras === 0) return sock.sendMessage(jid, { text: `🎩💢 Sem terra! Use *!comprarterra*` }, { quoted: msg })
        if (u.plantacoes.length >= u.terras) return sock.sendMessage(jid, { text: `🎩💢 Todas as terras ocupadas! ${u.plantacoes.length}/${u.terras}` }, { quoted: msg })

        const sem = acharSemente(args.join(" "))
        if (!sem) return sock.sendMessage(jid, { text: `🎩❌ Não achei! Veja *!sementes*` }, { quoted: msg })
        if ((u.sementes[sem.id] || 0) < 1) return sock.sendMessage(jid, { text: `🎩💢 Você não tem *${sem.nome}*!` }, { quoted: msg })

        u.sementes[sem.id]--
        if (u.sementes[sem.id] === 0) delete u.sementes[sem.id]

        u.plantacoes.push({
          id: sem.id, nome: sem.nome, emoji: sem.emoji,
          plantadaEm: Date.now(), regas: 0, qualidadeBase: 30,
          pronta: false, prontaEm: null
        })

        dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, {
          text: `🎩${sem.emoji} *${sem.nome}* plantada!\n⏰ ~${sem.tempo}min\n💧 Use *!regarplanta ${sem.nome}*`,
          mentions: [sender]
        }, { quoted: msg })
      }
    },

    regarsementes: {
      aliases: ["regartudo", "regartodas"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)

        if (!u.plantacoes.length) return sock.sendMessage(jid, { text: `🎩🌱 Sem plantações!` }, { quoted: msg })
        if (u.agua < AGUA_POR_REGA) return sock.sendMessage(jid, { text: `🎩💧 Sem água! Use *!compraragua*` }, { quoted: msg })

        let regadas = 0
        for (const p of u.plantacoes) {
          if (u.agua < AGUA_POR_REGA) break
          if (p.pronta) continue
          u.agua -= AGUA_POR_REGA
          p.regas = (p.regas || 0) + 1
          p.qualidadeBase = Math.min(100, (p.qualidadeBase || 30) + 5)
          regadas++
        }

        dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, {
          text: `🎩💧 *${regadas}* planta(s) regadas!\n💼 Água: *${u.agua}L*`,
          mentions: [sender]
        }, { quoted: msg })
      }
    },

    regarplanta: {
      aliases: ["regar"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)

        if (u.agua < AGUA_POR_REGA) return sock.sendMessage(jid, { text: `🎩💧 Sem água!` }, { quoted: msg })

        const busca = normalizar(args.join(" "))
        const p = u.plantacoes.find(x => normalizar(x.nome) === busca || x.id === busca || normalizar(x.nome).includes(busca))
        if (!p) return sock.sendMessage(jid, { text: `🎩❌ Planta não encontrada!` }, { quoted: msg })
        if (p.pronta) return sock.sendMessage(jid, { text: `🎩✅ Já está pronta! Use *!venderplanta ${p.nome}*` }, { quoted: msg })

        u.agua -= AGUA_POR_REGA
        p.regas = (p.regas || 0) + 1
        p.qualidadeBase = Math.min(100, (p.qualidadeBase || 30) + 5)

        dbSalvar("fazenda.json", f)
        await sock.sendMessage(jid, {
          text: `🎩${p.emoji} *${p.nome}* regada!\n💧 Água: *${u.agua}L*\n📊 Regas: *${p.regas}*`,
          mentions: [sender]
        }, { quoted: msg })
      }
    },

    venderplanta: {
      aliases: ["vender", "colher"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { f, u } = getFazenda(num)

        const busca = normalizar(args.join(" "))
        if (!busca) return sock.sendMessage(jid, { text: `🎩🌸 Use *!venderplanta <nome>*` }, { quoted: msg })

        const idx = u.plantacoes.findIndex(x => normalizar(x.nome) === busca || x.id === busca || normalizar(x.nome).includes(busca))
        if (idx === -1) return sock.sendMessage(jid, { text: `🎩❌ Você não tem essa planta!` }, { quoted: msg })

        const p = u.plantacoes[idx]
        if (!p.pronta) return sock.sendMessage(jid, { text: `🎩⏰ Ainda não está pronta!` }, { quoted: msg })

        const valor = valorPlanta(p)
        const qualidade = qualidadePlanta(p)
        u.plantacoes.splice(idx, 1)

        const rpg = db.rpg()
        rpg.usuarios[num] = rpg.usuarios[num] || { moedas: 0 }
        rpg.usuarios[num].moedas = (rpg.usuarios[num].moedas || 0) + valor

        db.salvarRpg(rpg); dbSalvar("fazenda.json", f)

        const estrelas = qualidade >= 90 ? "🎩⭐⭐" : qualidade >= 70 ? "⭐⭐" : qualidade >= 50 ? "⭐" : ""
        await sock.sendMessage(jid, {
          text: `🎩${p.emoji} *${p.nome}* vendida!\n📊 Qualidade: *${qualidade}%* ${estrelas}\n💵 *+${valor}*\n💼 *${rpg.usuarios[num].moedas}*`,
          mentions: [sender]
        }, { quoted: msg })
      }
    },

    statusplanta: {
      aliases: ["minhasplantas", "plantacoes"],
      async executar({ sock, msg, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = utils.soNumero(sender)
        const { u } = getFazenda(num)
        if (!u.plantacoes.length) return sock.sendMessage(jid, { text: `🎩🌱 Sem plantações!` }, { quoted: msg })

        let txt = `🎩🌱 *PLANTAÇÕES* (${u.plantacoes.length}/${u.terras})\n\n`
        for (const p of u.plantacoes) {
          const q = qualidadePlanta(p)
          const estrelas = q >= 90 ? "🎩⭐⭐" : q >= 70 ? "⭐⭐" : q >= 50 ? "⭐" : ""
          const status = p.pronta ? "✅ Pronta!" : `⏰ Crescendo...`
          txt += `🎩 ${p.emoji} *${p.nome}*\n   ${status}\n   📊 ${q}% ${estrelas}\n   💧 Regas: ${p.regas || 0}\n\n`
        }
        await sock.sendMessage(jid, { text: txt, mentions: [sender] }, { quoted: msg })
      }
    }

  }
}