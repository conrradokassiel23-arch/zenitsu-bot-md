/* ============================================================
   🎩 MENU RPG - NAPOLEÃO BONAPARTE
   ============================================================ */

const fs = require("fs")
const path = require("path")
const os = require("os")
const { execSync } = require("child_process")

const DATA_DIR = path.join(__dirname, "..", "..", "data")

function dbLer(arquivo, padrao = {}) {
  const p = path.join(DATA_DIR, arquivo)
  if (!fs.existsSync(p)) {
    fs.writeFileSync(p, JSON.stringify(padrao, null, 2))
    return padrao
  }
  try { return JSON.parse(fs.readFileSync(p, "utf8")) } catch { return padrao }
}

function dbSalvar(arquivo, dados) {
  fs.writeFileSync(path.join(DATA_DIR, arquivo), JSON.stringify(dados, null, 2))
}

function normalizar(s) {
  return String(s || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim()
}

function fmt(v) {
  if (typeof v !== "number" || isNaN(v) || !isFinite(v)) return "0"
  if (v > 999999999999) v = 999999999999
  if (v < 0) v = 0
  return Math.floor(v).toLocaleString("pt-BR")
}

function soNumero(jid) {
  if (!jid) return ""
  if (typeof jid === "object") jid = jid.phoneNumber || jid.id || ""
  return String(jid).split("@")[0].split(":")[0].replace(/\D/g, "")
}

function mJid(numeroOuJid) {
  const n = soNumero(numeroOuJid)
  if (!n) return null
  if (n.length >= 10 && n.length <= 15) return n + "@s.whatsapp.net"
  return String(numeroOuJid)
}

function formatarTempo(ms) {
  const s = Math.floor(ms / 1000)
  const m = Math.floor(s / 60)
  const h = Math.floor(m / 60)
  const d = Math.floor(h / 24)
  if (d > 0) return d + "d " + (h % 24) + "h"
  if (h > 0) return h + "h " + (m % 60) + "min"
  if (m > 0) return m + "min " + (s % 60) + "s"
  return s + "s"
}

function sanearNum(v, max = 999999999999) {
  if (typeof v !== "number" || isNaN(v) || !isFinite(v)) return 0
  if (v < 0) return 0
  if (v > max) return max
  return Math.floor(v)
}

const lidCache = new Map()

async function resolverNumero(sock, jidGrupo, jid) {
  if (!jid) return ""
  const s = String(jid)
  if (s.endsWith("@s.whatsapp.net")) return soNumero(s)

  if (s.endsWith("@lid") && jidGrupo) {
    const chaveCache = jidGrupo + "|" + s
    if (lidCache.has(chaveCache)) return lidCache.get(chaveCache)

    try {
      const meta = await sock.groupMetadata(jidGrupo)
      const lidNum = soNumero(s)
      const p = meta.participants.find(x => soNumero(x.id) === lidNum || soNumero(x.lid) === lidNum)
      if (p) {
        if (p.phoneNumber) {
          const rn = soNumero(p.phoneNumber)
          lidCache.set(chaveCache, rn)
          return rn
        }
        if (p.id && !String(p.id).endsWith("@lid")) {
          const rn = soNumero(p.id)
          lidCache.set(chaveCache, rn)
          return rn
        }
      }
    } catch (_) {}
    return soNumero(s)
  }

  return soNumero(s)
}

async function coletarMembros(sock, jidGrupo) {
  const numeros = new Set()
  try {
    const meta = await sock.groupMetadata(jidGrupo)
    for (const p of meta.participants) {
      if (p.phoneNumber) {
        const n = soNumero(p.phoneNumber)
        if (n && n.length >= 10 && n.length <= 15) numeros.add(n)
      }
    }
  } catch (_) {}
  return { numeros }
}

const PETS = [
  {
    id: "raposa", nome: "Raposa", emoji: "🦊", preco: 700, vip: false,
    buff: "15% de roubar alguém aleatório a cada 3h",
    forca: 30, velocidade: 50,
    rouboAuto: { chance: 0.15, intervalo: 3 * 60 * 60 * 1000 }
  },
  {
    id: "onca", nome: "Onça", emoji: "🐆", preco: 1000, vip: false,
    buff: "+40% de chance em corridapet, mais forte em batalhapet",
    forca: 60, velocidade: 70,
    corridaBonus: 0.40
  },
  {
    id: "ursoPolar", nome: "Urso Polar", emoji: "🐻‍❄️", preco: 1500, vip: false,
    buff: "+10% sorte em pescar, -15% em todos os pets da loja",
    forca: 75, velocidade: 40,
    pescaBonus: 0.10, descontoLoja: 0.15
  },
  {
    id: "unicornio", nome: "Unicórnio", emoji: "🦄", preco: 2000, vip: true,
    buff: "+10% sorte, +10% proteção roubo, 5% roubar auto a cada 2h, +1% level up daily, +5% gold no trabalhar",
    forca: 80, velocidade: 90,
    sorteBonus: 0.10, protecaoRoubo: 0.10,
    rouboAuto: { chance: 0.05, intervalo: 2 * 60 * 60 * 1000 },
    levelUpBonus: 0.01, trabalharBonus: 0.05
  }
]

function acharPet(nome) {
  const n = normalizar(nome)
  return PETS.find(p => normalizar(p.nome) === n || p.id === n || normalizar(p.nome).includes(n))
}

const PRECO_PICARETA = 800
const PRECO_VARA = 500
const COOLDOWN_TRABALHO = 60 * 60 * 1000
const COOLDOWN_ROUBO = 30 * 60 * 1000
const COOLDOWN_CRIME = 30 * 60 * 1000
const COOLDOWN_MINERAR = 20 * 60 * 1000
const COOLDOWN_PESCAR = 20 * 60 * 1000
const COOLDOWN_CORRIDA = 15 * 60 * 1000
const COOLDOWN_BATALHA = 20 * 60 * 1000
const COOLDOWN_EXPLORAR = 30 * 60 * 1000
const NIVEL_MIN_EXPLORAR = 3

const MINERIOS = [
  { nome: "Pedra", emoji: "🪨", valor: 20, chance: 0.40 },
  { nome: "Carvão", emoji: "⚫", valor: 50, chance: 0.25 },
  { nome: "Ferro", emoji: "⛓️", valor: 120, chance: 0.18 },
  { nome: "Ouro", emoji: "🥇", valor: 400, chance: 0.10 },
  { nome: "Diamante", emoji: "💎", valor: 1200, chance: 0.06 },
  { nome: "Esmeralda", emoji: "💚", valor: 800, chance: 0.01 }
]

const PEIXES = [
  { nome: "Sardinha", emoji: "🐟", valor: 15, chance: 0.35 },
  { nome: "Tilápia", emoji: "🐠", valor: 40, chance: 0.25 },
  { nome: "Bagre", emoji: "🐡", valor: 90, chance: 0.18 },
  { nome: "Dourado", emoji: "🐟", valor: 250, chance: 0.12 },
  { nome: "Pintado", emoji: "🐟", valor: 500, chance: 0.07 },
  { nome: "Tambaqui", emoji: "🐟", valor: 900, chance: 0.02 },
  { nome: "Peixe Lendário", emoji: "🐉", valor: 3000, chance: 0.01 }
]

const EXPLORAR = [
  { nome: "Floresta Sombria", emoji: "🌲", min: 300, max: 800, xp: 30 },
  { nome: "Caverna Profunda", emoji: "🕳️", min: 500, max: 1500, xp: 50 },
  { nome: "Ruínas Antigas", emoji: "🏛️", min: 800, max: 2000, xp: 70 },
  { nome: "Vulcão Adormecido", emoji: "🌋", min: 1000, max: 3000, xp: 100 },
  { nome: "Templo Perdido", emoji: "⛩️", min: 1500, max: 4000, xp: 120 },
  { nome: "Cidade Abandonada", emoji: "🏚️", min: 600, max: 1800, xp: 60 },
  { nome: "Deserto Infinito", emoji: "🏜️", min: 400, max: 1200, xp: 45 },
  { nome: "Ilha Misteriosa", emoji: "🏝️", min: 2000, max: 5000, xp: 150 }
]

function sortearPorChance(lista) {
  const r = Math.random()
  let acumulado = 0
  for (const item of lista) {
    acumulado += item.chance
    if (r <= acumulado) return item
  }
  return lista[0]
}

function getRpg(num) {
  const r = dbLer("rpg.json", { usuarios: {} })
  r.usuarios = r.usuarios || {}
  r.usuarios[num] = r.usuarios[num] || {}
  const u = r.usuarios[num]
  u.moedas = sanearNum(u.moedas)
  u.xp = sanearNum(u.xp, 999999)
  u.nivel = sanearNum(u.nivel, 9999) || 1
  u.ultimoTrabalho = sanearNum(u.ultimoTrabalho)
  u.ultimoRoubo = sanearNum(u.ultimoRoubo)
  u.ultimoCrime = sanearNum(u.ultimoCrime)
  u.ultimoMinerar = sanearNum(u.ultimoMinerar)
  u.ultimoPescar = sanearNum(u.ultimoPescar)
  u.ultimoCorrida = sanearNum(u.ultimoCorrida)
  u.ultimoBatalha = sanearNum(u.ultimoBatalha)
  u.ultimoExplorar = sanearNum(u.ultimoExplorar)
  u.temPicareta = u.temPicareta || false
  u.temVara = u.temVara || false
  u.pet = u.pet || null
  u.petGrupo = u.petGrupo || null
  u.petFome = u.petFome ?? 100
  u.petSede = u.petSede ?? 100
  u.petFelicidade = u.petFelicidade ?? 100
  u.petVida = u.petVida ?? 100
  u.petVidaMax = u.petVidaMax ?? 100
  u.ultimoRouboPet = sanearNum(u.ultimoRouboPet)
  u.daily = u.daily || 0
  return { r, u }
}

function salvarRpg(r) {
  dbSalvar("rpg.json", r)
}

function ehVip(db, sender, isDono, isSubDono) {
  if (isDono || isSubDono) return true
  const num = soNumero(sender)
  const v = (db.vips() || {}).vips || {}
  for (const [jidVip, info] of Object.entries(v)) {
    const n = soNumero(jidVip)
    if (n === num && (info.expira === "inf" || info.expira > Date.now())) return true
  }
  return false
}

function xpNecessario(nivel) {
  return Math.floor(100 * Math.pow(1.5, nivel - 1))
}

function ganharXp(u, qtd) {
  u.xp = sanearNum((u.xp || 0) + qtd, 999999)
  let subiu = 0
  while (u.xp >= xpNecessario(u.nivel) && subiu < 100) {
    u.xp -= xpNecessario(u.nivel)
    u.nivel++
    subiu++
  }
  return subiu
}

function precoComDesconto(preco, temUrso) {
  if (!temUrso) return preco
  return Math.floor(preco * 0.85)
}

// ══════════════════════════════════════════════════════════════
// 🎵 DOWNLOAD DE MÚSICA VIA YT-DLP (GRÁTIS, SEM API)
// ══════════════════════════════════════════════════════════════
function baixarMusica(busca) {
  const tmpDir = os.tmpdir()
  const id = Date.now() + "_" + Math.floor(Math.random() * 9999)
  const outTpl = path.join(tmpDir, "nap_mus_" + id + ".%(ext)s")

  // Detecta se é URL do YouTube ou busca por texto
  const ehUrl = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be|music\.youtube\.com)/i.test(busca)
  const alvo = ehUrl ? busca : "ytsearch1:" + busca

  // Tenta yt-dlp (binário instalado)
  const cmds = [
    `yt-dlp -x --audio-format mp3 --audio-quality 5 -o "${outTpl}" --no-playlist --max-filesize 20M "${alvo}"`,
    `python3 -m yt_dlp -x --audio-format mp3 --audio-quality 5 -o "${outTpl}" --no-playlist --max-filesize 20M "${alvo}"`,
    `python -m yt_dlp -x --audio-format mp3 --audio-quality 5 -o "${outTpl}" --no-playlist --max-filesize 20M "${alvo}"`
  ]

  let ultimoErro = "yt-dlp não encontrado"
  for (const cmd of cmds) {
    try {
      execSync(cmd, { stdio: "ignore", timeout: 60000 })
      // Procura o arquivo gerado
      const prefixo = "nap_mus_" + id
      const arquivos = fs.readdirSync(tmpDir).filter(f => f.startsWith(prefixo) && (f.endsWith(".mp3") || f.endsWith(".m4a") || f.endsWith(".webm") || f.endsWith(".opus")))
      if (arquivos.length > 0) {
        const caminho = path.join(tmpDir, arquivos[0])
        const buffer = fs.readFileSync(caminho)
        try { fs.unlinkSync(caminho) } catch (_) {}
        return { ok: true, buffer }
      }
    } catch (e) {
      ultimoErro = e.message
    }
  }

  return { ok: false, erro: ultimoErro }
}

module.exports = {
  menu: "menu-rpg",
  grupoOnly: false,
  adminOnly: false,
  donoOnly: false,

  async rendaAutomatica(sock, db) {
    const r = dbLer("rpg.json", { usuarios: {} })
    let alterou = false
    const agora = Date.now()

    for (const [num, u] of Object.entries(r.usuarios || {})) {
      if (!u.pet) continue
      const petInfo = PETS.find(p => p.id === u.pet)
      if (!petInfo || !petInfo.rouboAuto) continue
      if ((agora - (u.ultimoRouboPet || 0)) < petInfo.rouboAuto.intervalo) continue

      const grupoPet = u.petGrupo
      if (!grupoPet) continue

      const grupos = db.grupos()
      if (grupos[grupoPet]?.rpgAtivo !== true) continue

      const { numeros } = await coletarMembros(sock, grupoPet)
      const membrosArr = Array.from(numeros)

      const vitimas = membrosArr
        .filter(n => n !== num)
        .map(n => ({ num: n, u: r.usuarios[n] }))
        .filter(x => x.u && sanearNum(x.u.moedas) > 100 && x.u.pet !== "unicornio")

      if (!vitimas.length) continue

      const vitima = vitimas[Math.floor(Math.random() * vitimas.length)]
      const moedasVitima = sanearNum(vitima.u.moedas)
      const roubado = Math.min(
        Math.floor(moedasVitima * (petInfo.rouboAuto.chance > 0.10 ? 0.12 : 0.08)),
        10000
      )
      if (roubado <= 0) continue

      vitima.u.moedas = sanearNum(moedasVitima - roubado)
      r.usuarios[num].moedas = sanearNum(sanearNum(r.usuarios[num].moedas) + roubado)
      r.usuarios[num].ultimoRouboPet = agora
      r.usuarios[num].petFome = Math.min(100, sanearNum(r.usuarios[num].petFome) + 20)
      alterou = true

      try {
        await sock.sendMessage(grupoPet, {
          text: petInfo.emoji + " O *" + petInfo.nome + "* de @" + num + " roubou *" + fmt(roubado) + " gold* de @" + vitima.num + "!",
          mentions: [mJid(num), mJid(vitima.num)]
        })
      } catch (_) {}
    }
    if (alterou) salvarRpg(r)
  },

  commands: {

    menurpg: {
      aliases: ["comandosrpg", "menur"],
      async executar({ sock, msg, prefixoAtivo, db }) {
        const jid = msg.key.remoteJid
        const p = prefixoAtivo || "!"
        const cfg = db.config()

        const texto =
`╔══════════════════════════════╗
║   🎩⚔️  𝐌𝐄𝐍𝐔 𝐑𝐏𝐆  ⚔️🎩
╚══════════════════════════════╝

🦅 *Napoleão apresenta:*
🎩 *o mundo do império!*

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩💰 *ECONOMIA*
▸ ${p}daily
▸ ${p}trabalhar
▸ ${p}cassino <valor>
▸ ${p}crime
▸ ${p}roubar @user

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩⛏️ *FERRAMENTAS*
▸ ${p}comprarpicareta
▸ ${p}minerar
▸ ${p}comprarvara
▸ ${p}pescar

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩🗺️ *EXPLORAÇÃO* (Nv. 3+)
▸ ${p}explorar

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩🐾 *PETS*
▸ ${p}lojapet
▸ ${p}comprarpet <nome>
▸ ${p}meupet
▸ ${p}alimentarpet
▸ ${p}curarpet
▸ ${p}batalhapet @user
▸ ${p}corridapet @user
▸ ${p}venderpet <nome>
▸ ${p}doarpet <nome> @user

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩🎵 *MÚSICA*
▸ ${p}play <nome ou link>

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩👤 *PERFIL*
▸ ${p}perfil
▸ ${p}rank

━━━━━━━━━━━━━━━━━━━━━━━━━
🎩💤 *AFK*
▸ ${p}afk <motivo>

━━━━━━━━━━━━━━━━━━━━━━━━━

🦅 _"O império recompensa os fortes."_`

        if (cfg.fotoMenu) {
          const buf = Buffer.from(cfg.fotoMenu, "base64")
          if (cfg.tipoMenu === "video") return sock.sendMessage(jid, { video: buf, mimetype: "video/mp4", fileName: "napoleao.mp4", gifPlayback: true, caption: texto }, { quoted: msg })
          return sock.sendMessage(jid, { image: buf, caption: texto }, { quoted: msg })
        }
        await sock.sendMessage(jid, { text: texto }, { quoted: msg })
      }
    },

    rpg: {
      aliases: ["rpgativo", "ativarrpg", "rpgonoff"],
      adminOnly: true,
      grupoOnly: true,
      async executar({ sock, msg, args, db }) {
        const jid = msg.key.remoteJid
        const opcao = (args[0] || "").toLowerCase()
        if (!["on", "off"].includes(opcao)) {
          const g = db.grupos()
          const ativo = g[jid]?.rpgAtivo === true
          return sock.sendMessage(jid, {
            text: "🎩⚔️ *RPG DO GRUPO*\n\n📊 Status: *" + (ativo ? "ON ✅" : "OFF ❌") + "*\n\n🦅 Use *!rpg on* ou *!rpg off*"
          }, { quoted: msg })
        }
        const g = db.grupos()
        g[jid] = g[jid] || {}
        g[jid].rpgAtivo = opcao === "on"
        db.salvarGrupos(g)
        await sock.sendMessage(jid, {
          text: opcao === "on"
            ? "╔══════════════════════════════╗\n║   🎩⚔️ 𝐑𝐏𝐆 𝐀𝐓𝐈𝐕𝐀𝐃𝐎 ⚔️🎩\n╚══════════════════════════════╝\n\n🦅 Os comandos de RPG agora funcionam!\n🎩 _\"Que os jogos comecem.\"_"
            : "╔══════════════════════════════╗\n║   🎩💤 𝐑𝐏𝐆 𝐃𝐄𝐒𝐀𝐓𝐈𝐕𝐀𝐃𝐎 💤🎩\n╚══════════════════════════════╝\n\n🦅 RPG pausado neste território.\n🎩 _\"Voltaremos em breve.\"_"
        }, { quoted: msg })
      }
    },

    // ============ MÚSICA (yt-dlp local) ============
    play: {
      aliases: ["tocar", "musica", "music", "mp3"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const busca = args.join(" ").trim()
        if (!busca) return sock.sendMessage(jid, { text: "🎩🎵 Use *!play <nome ou link do YouTube>*" }, { quoted: msg })

        await sock.sendMessage(jid, { text: "🎩🎵 Baixando *" + busca + "*...\n\n⏳ Aguarde..." }, { quoted: msg })

        try {
          const res = baixarMusica(busca)
          if (!res.ok) {
            return sock.sendMessage(jid, {
              text: "╔══════════════════════════════╗\n║   🎩🎵 𝐄𝐑𝐑𝐎\n╚══════════════════════════════╝\n\n❌ Não consegui baixar!\n\n⚠️ Verifique se *yt-dlp* e *ffmpeg* estão instalados no servidor.\n\n💡 Instale com:\n• *pip install yt-dlp*\n• *apt install ffmpeg*"
            }, { quoted: msg })
          }

          const buffer = res.buffer
          const tamanhoMB = (buffer.length / 1024 / 1024).toFixed(2)
          if (buffer.length > 16 * 1024 * 1024) {
            return sock.sendMessage(jid, { text: "🎩💢 Música muito grande! (" + tamanhoMB + "MB)\n💡 Máximo: 16MB" }, { quoted: msg })
          }

          await sock.sendMessage(jid, {
            audio: buffer,
            mimetype: "audio/mp4",
            ptt: false,
            fileName: (busca.length > 30 ? busca.slice(0, 30) : busca) + ".mp3"
          }, { quoted: msg })

          console.log("✅ Música enviada: " + busca + " (" + tamanhoMB + "MB)")

        } catch (e) {
          console.log("Erro play:", e.message)
          await sock.sendMessage(jid, {
            text: "🎩💢 Erro ao baixar música!\n\n⚠️ " + e.message
          }, { quoted: msg })
        }
      }
    },

    // ============ ADDGOLD (dono) ============
    addgold: {
      aliases: ["dargold", "setgold"],
      donoOnly: true,
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) return sock.sendMessage(jid, { text: "🎩💰 Use *!addgold @user <valor>*" }, { quoted: msg })

        const numAlvo = await resolverNumero(sock, jid, alvo)
        if (!numAlvo) return sock.sendMessage(jid, { text: "🎩💢 Não consegui identificar o alvo!" }, { quoted: msg })

        const valor = Math.floor(parseInt(args.filter(a => !a.startsWith("@"))[0]) || 0)
        if (!valor) return sock.sendMessage(jid, { text: "🎩💰 Use *!addgold @user <valor>*" }, { quoted: msg })

        const { r, u } = getRpg(numAlvo)
        if (valor > 0) u.moedas = sanearNum(u.moedas + valor)
        else u.moedas = sanearNum(Math.max(0, u.moedas + valor))
        salvarRpg(r)

        const sinal = valor > 0 ? "+" : ""
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   🎩💰 𝐀𝐃𝐌𝐈𝐍 𝐆𝐎𝐋𝐃 💰🎩\n╚══════════════════════════════╝\n\n👤 @" + numAlvo + "\n💵 Ajuste: *" + sinal + fmt(valor) + " gold*\n💼 Novo saldo: *" + fmt(u.moedas) + "*",
          mentions: [mJid(numAlvo)]
        }, { quoted: msg })
      }
    },

    // ============ ADDXP (dono) ============
    addxp: {
      aliases: ["darxp", "setxp"],
      donoOnly: true,
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) return sock.sendMessage(jid, { text: "🎩🎯 Use *!addxp @user <valor>*" }, { quoted: msg })

        const numAlvo = await resolverNumero(sock, jid, alvo)
        if (!numAlvo) return sock.sendMessage(jid, { text: "🎩💢 Não consegui identificar!" }, { quoted: msg })

        const valor = Math.floor(parseInt(args.filter(a => !a.startsWith("@"))[0]) || 0)
        if (!valor) return sock.sendMessage(jid, { text: "🎩🎯 Use *!addxp @user <valor>*" }, { quoted: msg })

        const { r, u } = getRpg(numAlvo)
        let subiu = 0
        if (valor > 0) subiu = ganharXp(u, valor)
        else u.xp = Math.max(0, u.xp + valor)
        salvarRpg(r)

        const sinal = valor > 0 ? "+" : ""
        let txt = "╔══════════════════════════════╗\n║   🎩🎯 𝐀𝐃𝐌𝐈𝐍 𝐗𝐏 🎯🎩\n╚══════════════════════════════╝\n\n"
        txt += "👤 @" + numAlvo + "\n🎯 Ajuste: *" + sinal + fmt(valor) + " XP*\n"
        txt += "📊 XP: *" + u.xp + "/" + xpNecessario(u.nivel) + "*\n🎖️ Nível: *" + u.nivel + "*"
        if (subiu) txt += "\n⬆️ Subiu *" + subiu + "* nível!"

        await sock.sendMessage(jid, { text: txt, mentions: [mJid(numAlvo)] }, { quoted: msg })
      }
    },

    // ============ EXPLORAR ============
    explorar: {
      aliases: ["exploracao", "aventura", "exp"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        if (u.nivel < NIVEL_MIN_EXPLORAR) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   🎩🗺️ 𝐄𝐗𝐏𝐋𝐎𝐑𝐀𝐑\n╚══════════════════════════════╝\n\n💢 Você precisa ser *Nível " + NIVEL_MIN_EXPLORAR + "* ou mais!\n\n📊 Seu nível: *" + u.nivel + "*\n🎯 Falta: *" + (NIVEL_MIN_EXPLORAR - u.nivel) + "* nível(is)"
          }, { quoted: msg })
        }

        const cooldown = COOLDOWN_EXPLORAR - (Date.now() - u.ultimoExplorar)
        if (cooldown > 0) return sock.sendMessage(jid, { text: "🎩⏰ Espere *" + formatarTempo(cooldown) + "* pra explorar de novo!" }, { quoted: msg })

        u.ultimoExplorar = Date.now()
        const local = EXPLORAR[Math.floor(Math.random() * EXPLORAR.length)]
        const sucesso = Math.random() < 0.75

        if (sucesso) {
          const valor = Math.floor(local.min + Math.random() * (local.max - local.min))
          const xp = local.xp + Math.floor(Math.random() * 20)
          u.moedas = sanearNum(u.moedas + valor)
          const subiu = ganharXp(u, xp)
          salvarRpg(r)

          let txt = "╔══════════════════════════════╗\n║   🎩🗺️ 𝐄𝐗𝐏𝐋𝐎𝐑𝐀𝐐𝐀̃𝐎 🗺️🎩\n╚══════════════════════════════╝\n\n"
          txt += "👤 @" + num + "\n" + local.emoji + " Local: *" + local.nome + "*\n\n"
          txt += "💰 Encontrou: *+" + fmt(valor) + " gold*\n🎯 XP: *+" + xp + "*"
          if (subiu) txt += "\n⬆️ Subiu *" + subiu + "* nível!"
          await sock.sendMessage(jid, { text: txt, mentions: [mJid(num)] }, { quoted: msg })
        } else {
          const perda = Math.floor((u.moedas || 0) * 0.05)
          u.moedas = sanearNum(Math.max(0, u.moedas - perda))
          ganharXp(u, 5)
          salvarRpg(r)
          await sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   🎩🗺️ 𝐄𝐗𝐏𝐋𝐎𝐑𝐀𝐐𝐀̃𝐎 🗺️🎩\n╚══════════════════════════════╝\n\n👤 @" + num + "\n" + local.emoji + " Local: *" + local.nome + "*\n\n💢 Você se perdeu!\n💸 Perdeu: *-" + fmt(perda) + " gold*\n🎯 XP: *+5*",
            mentions: [mJid(num)]
          }, { quoted: msg })
        }
      }
    },

    // ============ DEBUG ============
    debugrank: {
      aliases: ["dbgrank", "dbg"],
      adminOnly: true,
      grupoOnly: true,
      async executar({ sock, msg }) {
        const jid = msg.key.remoteJid
        try {
          const meta = await sock.groupMetadata(jid)
          let txt = "🔍 *DEBUG*\n\n📊 Total: *" + meta.participants.length + "*\n\n"
          for (const p of meta.participants) {
            txt += "PN: " + (p.phoneNumber || "❌") + "\n"
            txt += "LID: " + (p.lid || p.id || "?") + "\n───\n"
          }
          await sock.sendMessage(jid, { text: txt }, { quoted: msg })
        } catch (e) {
          await sock.sendMessage(jid, { text: "Erro: " + e.message }, { quoted: msg })
        }
      }
    },

    daily: {
      aliases: ["diario"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        const hoje = new Date().toISOString().slice(0, 10)
        if (u.daily === hoje) return sock.sendMessage(jid, { text: "🎩⏰ Você já pegou seu *daily* hoje!\n🦅 Volte amanhã." }, { quoted: msg })

        let valor = 200 + u.nivel * 50
        let msgExtra = ""
        if (u.pet === "unicornio" && Math.random() < 0.01) {
          const subiu = ganharXp(u, xpNecessario(u.nivel))
          valor += 500
          msgExtra = "\n\n🦄 *BÔNUS UNICÓRNIO!*\n⬆️ Subiu *" + subiu + "* nível!\n💰 +500 gold"
        }

        u.moedas = sanearNum(u.moedas + valor)
        u.daily = hoje
        const subiuNivel = ganharXp(u, 25)
        salvarRpg(r)

        let txt = "╔══════════════════════════════╗\n║   🎩💰 𝐃𝐀𝐈𝐋𝐘 🎩💰\n╚══════════════════════════════╝\n\n"
        txt += "👤 @" + num + "\n💰 *+" + fmt(valor) + " gold*\n🎯 *+25 XP*"
        if (subiuNivel) txt += "\n⬆️ Subiu *" + subiuNivel + "* nível!"
        txt += msgExtra

        await sock.sendMessage(jid, { text: txt, mentions: [mJid(num)] }, { quoted: msg })
      }
    },

    trabalhar: {
      aliases: ["work", "trampar"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        const cooldown = COOLDOWN_TRABALHO - (Date.now() - u.ultimoTrabalho)
        if (cooldown > 0) return sock.sendMessage(jid, { text: "🎩⏰ Espere *" + formatarTempo(cooldown) + "*!" }, { quoted: msg })

        const trabalhos = ["entregador", "pedreiro", "motoqueiro", "vendedor", "programador", "garçom", "motorista"]
        const trabalho = trabalhos[Math.floor(Math.random() * trabalhos.length)]
        let salario = 100 + u.nivel * 30 + Math.floor(Math.random() * 100)

        let bonus = ""
        if (u.pet === "unicornio") {
          salario = Math.floor(salario * 1.05)
          bonus = "\n🦄 *Bônus Unicórnio: +5%*"
        }

        u.moedas = sanearNum(u.moedas + salario)
        u.ultimoTrabalho = Date.now()
        const subiu = ganharXp(u, 15)
        salvarRpg(r)

        let txt = "╔══════════════════════════════╗\n║   🎩💼 𝐓𝐑𝐀𝐁𝐀𝐋𝐇𝐎 🎩💼\n╚══════════════════════════════╝\n\n"
        txt += "👤 @" + num + "\n⚒️ Trabalhou como *" + trabalho + "*\n💰 *+" + fmt(salario) + " gold*"
        if (bonus) txt += bonus
        txt += "\n🎯 *+15 XP*"
        if (subiu) txt += "\n⬆️ Subiu *" + subiu + "* nível!"

        await sock.sendMessage(jid, { text: txt, mentions: [mJid(num)] }, { quoted: msg })
      }
    },

    cassino: {
      aliases: ["bet", "apostar"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        const valor = Math.floor(parseInt(args[0]) || 0)
        if (!valor || valor <= 0) return sock.sendMessage(jid, { text: "🎩🎰 Use *!cassino <valor>*" }, { quoted: msg })
        if (valor > u.moedas) return sock.sendMessage(jid, { text: "🎩💢 Você só tem *" + fmt(u.moedas) + "* gold!" }, { quoted: msg })

        const ganhou = Math.random() < 0.48
        const emoji = ["🎰", "🎲", "🃏"][Math.floor(Math.random() * 3)]

        if (ganhou) {
          u.moedas = sanearNum(u.moedas + valor)
          ganharXp(u, 10)
          salvarRpg(r)
          await sock.sendMessage(jid, {
            text: emoji + " *VOCÊ GANHOU!*\n\n👤 @" + num + "\n💰 *+" + fmt(valor) + "*\n💼 Total: *" + fmt(u.moedas) + "*",
            mentions: [mJid(num)]
          }, { quoted: msg })
        } else {
          u.moedas = sanearNum(u.moedas - valor)
          salvarRpg(r)
          await sock.sendMessage(jid, {
            text: emoji + " *VOCÊ PERDEU!*\n\n👤 @" + num + "\n💸 *-" + fmt(valor) + "*\n💼 Total: *" + fmt(u.moedas) + "*",
            mentions: [mJid(num)]
          }, { quoted: msg })
        }
      }
    },

    roubar: {
      aliases: ["assaltar", "roub4r"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) return sock.sendMessage(jid, { text: "🎩🔫 Use *!roubar @user*" }, { quoted: msg })

        const numReal = await resolverNumero(sock, jid, sender)
        const numAlvoReal = await resolverNumero(sock, jid, alvo)
        if (!numReal || !numAlvoReal) return sock.sendMessage(jid, { text: "🎩💢 Não consegui identificar!" }, { quoted: msg })
        if (numAlvoReal === numReal) return sock.sendMessage(jid, { text: "🎩❓ Não pode roubar você mesmo!" }, { quoted: msg })

        const { r, u } = getRpg(numReal)
        const { r: rAlvo, u: uAlvo } = getRpg(numAlvoReal)

        const cooldown = COOLDOWN_ROUBO - (Date.now() - u.ultimoRoubo)
        if (cooldown > 0) return sock.sendMessage(jid, { text: "🎩⏰ Espere *" + formatarTempo(cooldown) + "*!" }, { quoted: msg })
        if (uAlvo.moedas < 100) return sock.sendMessage(jid, { text: "🎩💢 @" + numAlvoReal + " é pobre demais!", mentions: [mJid(numAlvoReal)] }, { quoted: msg })

        u.ultimoRoubo = Date.now()
        let chance = 0.45
        if (uAlvo.pet === "unicornio") chance -= 0.10
        const sucesso = Math.random() < chance
        const valor = Math.min(Math.floor(uAlvo.moedas * (0.10 + Math.random() * 0.15)), 10000)

        if (sucesso) {
          u.moedas = sanearNum(u.moedas + valor)
          uAlvo.moedas = sanearNum(uAlvo.moedas - valor)
          ganharXp(u, 20)
          salvarRpg(r); salvarRpg(rAlvo)
          await sock.sendMessage(jid, {
            text: "🦹 *ROUBO BEM-SUCEDIDO!*\n\n👤 @" + numReal + "\n🎯 Alvo: @" + numAlvoReal + "\n💰 *+" + fmt(valor) + "*",
            mentions: [mJid(numReal), mJid(numAlvoReal)]
          }, { quoted: msg })
        } else {
          const multa = Math.floor(valor * 0.5)
          u.moedas = sanearNum(Math.max(0, u.moedas - multa))
          salvarRpg(r)
          await sock.sendMessage(jid, {
            text: "🚨 *ROUBO FALHOU!*\n\n👤 @" + numReal + "\n🎯 Alvo: @" + numAlvoReal + "\n💸 Multa: *-" + fmt(multa) + "*",
            mentions: [mJid(numReal), mJid(numAlvoReal)]
          }, { quoted: msg })
        }
      }
    },

    crime: {
      aliases: ["crimeurbano"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        const cooldown = COOLDOWN_CRIME - (Date.now() - u.ultimoCrime)
        if (cooldown > 0) return sock.sendMessage(jid, { text: "🎩⏰ Espere *" + formatarTempo(cooldown) + "*!" }, { quoted: msg })

        u.ultimoCrime = Date.now()
        const crimes = [
          { nome: "Assalto a banco", min: 500, max: 2000, risco: 0.55 },
          { nome: "Roubo de carro", min: 200, max: 800, risco: 0.40 },
          { nome: "Tráfico", min: 300, max: 1500, risco: 0.50 },
          { nome: "Contrabando", min: 400, max: 1800, risco: 0.45 },
          { nome: "Furto de loja", min: 100, max: 500, risco: 0.25 }
        ]
        const crime = crimes[Math.floor(Math.random() * crimes.length)]
        const ganhou = Math.random() > crime.risco

        if (ganhou) {
          const valor = Math.floor(crime.min + Math.random() * (crime.max - crime.min))
          u.moedas = sanearNum(u.moedas + valor)
          ganharXp(u, 25)
          salvarRpg(r)
          await sock.sendMessage(jid, {
            text: "🦹 *" + crime.nome.toUpperCase() + "*\n\n👤 @" + num + "\n💰 Botim: *+" + fmt(valor) + "*",
            mentions: [mJid(num)]
          }, { quoted: msg })
        } else {
          const multa = Math.floor(crime.min * 1.5)
          u.moedas = sanearNum(Math.max(0, u.moedas - multa))
          salvarRpg(r)
          await sock.sendMessage(jid, {
            text: "🚨 *" + crime.nome.toUpperCase() + "*\n\n👤 @" + num + "\n💸 Multa: *-" + fmt(multa) + "*",
            mentions: [mJid(num)]
          }, { quoted: msg })
        }
      }
    },

    comprarpicareta: {
      aliases: ["buypicareta", "picareta"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        if (u.temPicareta) return sock.sendMessage(jid, { text: "🎩⛏️ Você já tem uma *picareta*!" }, { quoted: msg })
        if (u.moedas < PRECO_PICARETA) return sock.sendMessage(jid, { text: "🎩💢 Faltam *" + fmt(PRECO_PICARETA - u.moedas) + "* gold!" }, { quoted: msg })

        u.moedas = sanearNum(u.moedas - PRECO_PICARETA)
        u.temPicareta = true
        salvarRpg(r)
        await sock.sendMessage(jid, {
          text: "🎩⛏️ *PICARETA COMPRADA!*\n\n💰 *-" + fmt(PRECO_PICARETA) + "*",
          mentions: [mJid(num)]
        }, { quoted: msg })
      }
    },

    minerar: {
      aliases: ["mine", "mineracao"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        if (!u.temPicareta) return sock.sendMessage(jid, { text: "🎩💢 Você precisa de uma *picareta*!" }, { quoted: msg })

        const cooldown = COOLDOWN_MINERAR - (Date.now() - u.ultimoMinerar)
        if (cooldown > 0) return sock.sendMessage(jid, { text: "🎩⏰ Espere *" + formatarTempo(cooldown) + "*!" }, { quoted: msg })

        u.ultimoMinerar = Date.now()
        const minerio = sortearPorChance(MINERIOS)
        u.moedas = sanearNum(u.moedas + minerio.valor)
        ganharXp(u, 10)
        salvarRpg(r)

        await sock.sendMessage(jid, {
          text: "⛏️ *MINERAÇÃO*\n\n👤 @" + num + "\n" + minerio.emoji + " Achou: *" + minerio.nome + "*\n💰 *+" + fmt(minerio.valor) + "*",
          mentions: [mJid(num)]
        }, { quoted: msg })
      }
    },

    comprarvara: {
      aliases: ["buyvara", "vara"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        if (u.temVara) return sock.sendMessage(jid, { text: "🎩🎣 Você já tem uma *vara*!" }, { quoted: msg })
        if (u.moedas < PRECO_VARA) return sock.sendMessage(jid, { text: "🎩💢 Faltam *" + fmt(PRECO_VARA - u.moedas) + "* gold!" }, { quoted: msg })

        u.moedas = sanearNum(u.moedas - PRECO_VARA)
        u.temVara = true
        salvarRpg(r)
        await sock.sendMessage(jid, {
          text: "🎩🎣 *VARA COMPRADA!*\n\n💰 *-" + fmt(PRECO_VARA) + "*",
          mentions: [mJid(num)]
        }, { quoted: msg })
      }
    },

    pescar: {
      aliases: ["pesca", "fish"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        if (!u.temVara) return sock.sendMessage(jid, { text: "🎩💢 Você precisa de uma *vara*!" }, { quoted: msg })

        const cooldown = COOLDOWN_PESCAR - (Date.now() - u.ultimoPescar)
        if (cooldown > 0) return sock.sendMessage(jid, { text: "🎩⏰ Espere *" + formatarTempo(cooldown) + "*!" }, { quoted: msg })

        u.ultimoPescar = Date.now()
        const peixe = sortearPorChance(PEIXES)
        let valor = peixe.valor
        let bonus = ""
        if (u.pet === "ursoPolar") {
          valor = Math.floor(valor * 1.10)
          bonus = "\n🐻‍❄️ *Bônus Urso Polar: +10%*"
        }
        u.moedas = sanearNum(u.moedas + valor)
        ganharXp(u, 12)
        salvarRpg(r)

        await sock.sendMessage(jid, {
          text: "🎣 *PESCARIA*\n\n👤 @" + num + "\n" + peixe.emoji + " Pescou: *" + peixe.nome + "*\n💰 *+" + fmt(valor) + "*" + bonus,
          mentions: [mJid(num)]
        }, { quoted: msg })
      }
    },

    lojapet: {
      aliases: ["petshop", "lojapets"],
      async executar({ sock, msg, db, utils, sender, isDono, isSubDono }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { u } = getRpg(num)
        const temUrso = u.pet === "ursoPolar"
        const ehVipUser = ehVip(db, sender, isDono, isSubDono)

        let txt = "╔══════════════════════════════╗\n║   🐾 𝐋𝐎𝐉𝐀 𝐃𝐄 𝐏𝐄𝐓𝐒 🐾\n╚══════════════════════════════╝\n\n"

        for (const pet of PETS) {
          const preco = precoComDesconto(pet.preco, temUrso && pet.id !== "unicornio")
          const tag = pet.vip ? " 💎VIP" : ""
          txt += pet.emoji + " *" + pet.nome + "*" + tag + "\n"
          txt += "💰 " + fmt(preco) + " gold\n"
          txt += "📜 " + pet.buff + "\n\n"
        }

        txt += "━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        if (temUrso) txt += "🐻‍❄️ *Urso Polar ativo: -15% em todos!*\n"
        if (ehVipUser) txt += "💎 *Você é VIP — Unicórnio liberado!*\n"
        txt += "\n💡 Use *!comprarpet <nome>*"

        await sock.sendMessage(jid, { text: txt }, { quoted: msg })
      }
    },

    comprarpet: {
      aliases: ["buypet", "adotarpet"],
      async executar({ sock, msg, args, db, utils, sender, isDono, isSubDono }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        if (u.pet) return sock.sendMessage(jid, { text: "🎩🐾 Você já tem um pet!" }, { quoted: msg })

        const pet = acharPet(args.join(" "))
        if (!pet) return sock.sendMessage(jid, { text: "🎩❌ Pet não achado! Veja *!lojapet*" }, { quoted: msg })
        if (pet.vip && !ehVip(db, sender, isDono, isSubDono)) {
          return sock.sendMessage(jid, { text: "🎩💎 O *" + pet.nome + "* é exclusivo VIP!" }, { quoted: msg })
        }

        const preco = precoComDesconto(pet.preco, u.pet === "ursoPolar" && pet.id !== "unicornio")
        if (u.moedas < preco) return sock.sendMessage(jid, { text: "🎩💢 Faltam *" + fmt(preco - u.moedas) + "* gold!" }, { quoted: msg })

        u.moedas = sanearNum(u.moedas - preco)
        u.pet = pet.id
        u.petGrupo = jid.endsWith("@g.us") ? jid : null
        u.petFome = 100
        u.petSede = 100
        u.petFelicidade = 100
        u.petVida = pet.forca * 10
        u.petVidaMax = pet.forca * 10
        u.ultimoRouboPet = Date.now()
        salvarRpg(r)

        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   🐾 𝐏𝐄𝐓 𝐀𝐃𝐎𝐓𝐀𝐃𝐎 🐾\n╚══════════════════════════════╝\n\n👤 @" + num + "\n" + pet.emoji + " *" + pet.nome + "*\n💰 *-" + fmt(preco) + "*\n\n📜 " + pet.buff,
          mentions: [mJid(num)]
        }, { quoted: msg })
      }
    },

    meupet: {
      aliases: ["pet", "statuspet"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { u } = getRpg(num)

        if (!u.pet) return sock.sendMessage(jid, { text: "🎩🐾 Você não tem pet!\n💡 Use *!lojapet*" }, { quoted: msg })

        const pet = PETS.find(p => p.id === u.pet)
        if (!pet) return sock.sendMessage(jid, { text: "🎩❌ Pet bugado!" }, { quoted: msg })

        const barra = (v) => {
          const c = Math.max(0, Math.min(10, Math.round(v / 10)))
          return "🟩".repeat(c) + "⬛".repeat(10 - c)
        }
        const statusIco = (v) => v > 70 ? "🟢" : v > 40 ? "🟡" : "🔴"

        const txt =
`╔══════════════════════════════╗
║   ${pet.emoji} 𝐌𝐄𝐔 𝐏𝐄𝐓 ${pet.emoji}
╚══════════════════════════════╝

👤 @${num}
🐾 *${pet.nome}*

━━━━━━━━━━━━━━━━━━━━━━━━━
🍖 Fome: ${statusIco(u.petFome)} *${u.petFome}%*
${barra(u.petFome)}

💧 Sede: ${statusIco(u.petSede)} *${u.petSede}%*
${barra(u.petSede)}

😊 Felicidade: ${statusIco(u.petFelicidade)} *${u.petFelicidade}%*
${barra(u.petFelicidade)}

❤️ Vida: ${statusIco(u.petVida / u.petVidaMax * 100)} *${u.petVida}/${u.petVidaMax}*
${barra(u.petVida / u.petVidaMax * 100)}

━━━━━━━━━━━━━━━━━━━━━━━━━
⚔️ Força: *${pet.forca}*
🏃 Velocidade: *${pet.velocidade}*
📜 Buff: ${pet.buff}`

        await sock.sendMessage(jid, { text: txt, mentions: [mJid(num)] }, { quoted: msg })
      }
    },

    alimentarpet: {
      aliases: ["feedpet", "darpet"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        if (!u.pet) return sock.sendMessage(jid, { text: "🎩🐾 Você não tem pet!" }, { quoted: msg })

        const custo = 50
        if (u.moedas < custo) return sock.sendMessage(jid, { text: "🎩💢 Precisa de *" + fmt(custo) + "* gold!" }, { quoted: msg })

        u.moedas = sanearNum(u.moedas - custo)
        u.petFome = Math.min(100, u.petFome + 30)
        u.petSede = Math.min(100, u.petSede + 20)
        u.petFelicidade = Math.min(100, u.petFelicidade + 10)
        salvarRpg(r)

        const pet = PETS.find(p => p.id === u.pet)
        await sock.sendMessage(jid, {
          text: pet.emoji + " *PET ALIMENTADO!*\n\n🍖 Fome: *" + u.petFome + "%*\n💧 Sede: *" + u.petSede + "%*\n💰 *-" + fmt(custo) + "*",
          mentions: [mJid(num)]
        }, { quoted: msg })
      }
    },

    curarpet: {
      aliases: ["healpet", "curar"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        if (!u.pet) return sock.sendMessage(jid, { text: "🎩🐾 Você não tem pet!" }, { quoted: msg })
        if (u.petVida >= u.petVidaMax) return sock.sendMessage(jid, { text: "🎩❤️ Vida cheia!" }, { quoted: msg })

        const falta = u.petVidaMax - u.petVida
        const custo = falta * 3
        if (u.moedas < custo) return sock.sendMessage(jid, { text: "🎩💢 Precisa de *" + fmt(custo) + "* gold!" }, { quoted: msg })

        u.moedas = sanearNum(u.moedas - custo)
        u.petVida = u.petVidaMax
        salvarRpg(r)

        const pet = PETS.find(p => p.id === u.pet)
        await sock.sendMessage(jid, {
          text: pet.emoji + " *PET CURADO!*\n\n❤️ Vida: *" + u.petVida + "/" + u.petVidaMax + "*\n💰 *-" + fmt(custo) + "*",
          mentions: [mJid(num)]
        }, { quoted: msg })
      }
    },

    venderpet: {
      aliases: ["sellpet"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { r, u } = getRpg(num)

        if (!u.pet) return sock.sendMessage(jid, { text: "🎩🐾 Você não tem pet!" }, { quoted: msg })

        const pet = PETS.find(p => p.id === u.pet)
        if (pet.vip) return sock.sendMessage(jid, { text: "🎩💎 Pets *VIP* não podem ser vendidos!" }, { quoted: msg })

        const valor = Math.floor(pet.preco * 0.6)
        u.moedas = sanearNum(u.moedas + valor)
        u.pet = null
        u.petGrupo = null
        salvarRpg(r)

        await sock.sendMessage(jid, {
          text: pet.emoji + " *PET VENDIDO!*\n\n" + pet.nome + "\n💰 *+" + fmt(valor) + "*",
          mentions: [mJid(num)]
        }, { quoted: msg })
      }
    },

    doarpet: {
      aliases: ["givepet", "presentepet"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) return sock.sendMessage(jid, { text: "🎩🎁 Use *!doarpet @user*" }, { quoted: msg })

        const numReal = await resolverNumero(sock, jid, sender)
        const numAlvoReal = await resolverNumero(sock, jid, alvo)
        if (!numReal || !numAlvoReal) return sock.sendMessage(jid, { text: "🎩💢 Não consegui identificar!" }, { quoted: msg })
        if (numAlvoReal === numReal) return sock.sendMessage(jid, { text: "🎩❓ Não pode doar pra você!" }, { quoted: msg })

        const { r, u } = getRpg(numReal)
        const { r: rAlvo, u: uAlvo } = getRpg(numAlvoReal)

        if (!u.pet) return sock.sendMessage(jid, { text: "🎩🐾 Você não tem pet!" }, { quoted: msg })
        if (uAlvo.pet) return sock.sendMessage(jid, { text: "🎩💢 @" + numAlvoReal + " já tem pet!", mentions: [mJid(numAlvoReal)] }, { quoted: msg })

        const pet = PETS.find(p => p.id === u.pet)
        if (pet.vip) return sock.sendMessage(jid, { text: "🎩💎 Pets *VIP* não podem ser doados!" }, { quoted: msg })

        uAlvo.pet = pet.id
        uAlvo.petGrupo = u.petGrupo
        uAlvo.petFome = u.petFome
        uAlvo.petSede = u.petSede
        uAlvo.petFelicidade = u.petFelicidade
        uAlvo.petVida = u.petVida
        uAlvo.petVidaMax = u.petVidaMax
        uAlvo.ultimoRouboPet = Date.now()

        u.pet = null
        u.petGrupo = null

        salvarRpg(r); salvarRpg(rAlvo)

        await sock.sendMessage(jid, {
          text: pet.emoji + " *PET DOADO!*\n\n👤 De: @" + numReal + "\n🎁 Para: @" + numAlvoReal + "\n🐾 *" + pet.nome + "*",
          mentions: [mJid(numReal), mJid(numAlvoReal)]
        }, { quoted: msg })
      }
    },

    batalhapet: {
      aliases: ["batalhar", "petbatalha"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) return sock.sendMessage(jid, { text: "🎩⚔️ Use *!batalhapet @user*" }, { quoted: msg })

        const numReal = await resolverNumero(sock, jid, sender)
        const numAlvoReal = await resolverNumero(sock, jid, alvo)
        if (!numReal || !numAlvoReal) return sock.sendMessage(jid, { text: "🎩💢 Não consegui identificar!" }, { quoted: msg })
        if (numAlvoReal === numReal) return sock.sendMessage(jid, { text: "🎩❓ Não pode batalhar consigo!" }, { quoted: msg })

        const { r, u } = getRpg(numReal)
        const { r: rAlvo, u: uAlvo } = getRpg(numAlvoReal)

        if (!u.pet) return sock.sendMessage(jid, { text: "🎩🐾 Você não tem pet!" }, { quoted: msg })
        if (!uAlvo.pet) return sock.sendMessage(jid, { text: "🎩🐾 @" + numAlvoReal + " não tem pet!", mentions: [mJid(numAlvoReal)] }, { quoted: msg })

        const cooldown = COOLDOWN_BATALHA - (Date.now() - u.ultimoBatalha)
        if (cooldown > 0) return sock.sendMessage(jid, { text: "🎩⏰ Espere *" + formatarTempo(cooldown) + "*!" }, { quoted: msg })

        u.ultimoBatalha = Date.now()
        const pet1 = PETS.find(p => p.id === u.pet)
        const pet2 = PETS.find(p => p.id === uAlvo.pet)
        const forca1 = pet1.forca * (u.petVida / u.petVidaMax) * (u.petFome / 100)
        const forca2 = pet2.forca * (uAlvo.petVida / uAlvo.petVidaMax) * (uAlvo.petFome / 100)
        const chance1 = forca1 / (forca1 + forca2)
        const venceu = Math.random() < chance1

        const premio = 100
        if (venceu) {
          const dano = Math.floor(uAlvo.petVidaMax * 0.3)
          uAlvo.petVida = Math.max(0, uAlvo.petVida - dano)
          u.moedas = sanearNum(u.moedas + premio)
          ganharXp(u, 20)
          salvarRpg(r); salvarRpg(rAlvo)
          await sock.sendMessage(jid, {
            text: "⚔️ *BATALHA*\n\n" + pet1.emoji + " @" + numReal + " VS " + pet2.emoji + " @" + numAlvoReal + "\n\n🏆 *@" + numReal + " VENCEU!*\n💰 *+" + premio + "*",
            mentions: [mJid(numReal), mJid(numAlvoReal)]
          }, { quoted: msg })
        } else {
          const dano = Math.floor(u.petVidaMax * 0.3)
          u.petVida = Math.max(0, u.petVida - dano)
          uAlvo.moedas = sanearNum(uAlvo.moedas + premio)
          ganharXp(uAlvo, 20)
          salvarRpg(r); salvarRpg(rAlvo)
          await sock.sendMessage(jid, {
            text: "⚔️ *BATALHA*\n\n" + pet1.emoji + " @" + numReal + " VS " + pet2.emoji + " @" + numAlvoReal + "\n\n🏆 *@" + numAlvoReal + " VENCEU!*\n💰 *+" + premio + "*",
            mentions: [mJid(numReal), mJid(numAlvoReal)]
          }, { quoted: msg })
        }
      }
    },

    corridapet: {
      aliases: ["corrida", "racepet"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) return sock.sendMessage(jid, { text: "🎩🏁 Use *!corridapet @user*" }, { quoted: msg })

        const numReal = await resolverNumero(sock, jid, sender)
        const numAlvoReal = await resolverNumero(sock, jid, alvo)
        if (!numReal || !numAlvoReal) return sock.sendMessage(jid, { text: "🎩💢 Não consegui identificar!" }, { quoted: msg })
        if (numAlvoReal === numReal) return sock.sendMessage(jid, { text: "🎩❓ Não pode correr consigo!" }, { quoted: msg })

        const { r, u } = getRpg(numReal)
        const { r: rAlvo, u: uAlvo } = getRpg(numAlvoReal)

        if (!u.pet) return sock.sendMessage(jid, { text: "🎩🐾 Você não tem pet!" }, { quoted: msg })
        if (!uAlvo.pet) return sock.sendMessage(jid, { text: "🎩🐾 @" + numAlvoReal + " não tem pet!", mentions: [mJid(numAlvoReal)] }, { quoted: msg })

        const cooldown = COOLDOWN_CORRIDA - (Date.now() - u.ultimoCorrida)
        if (cooldown > 0) return sock.sendMessage(jid, { text: "🎩⏰ Espere *" + formatarTempo(cooldown) + "*!" }, { quoted: msg })

        u.ultimoCorrida = Date.now()
        const pet1 = PETS.find(p => p.id === u.pet)
        const pet2 = PETS.find(p => p.id === uAlvo.pet)

        let bonus1 = 0, bonus2 = 0
        if (pet1.corridaBonus) bonus1 = pet1.corridaBonus
        if (pet2.corridaBonus) bonus2 = pet2.corridaBonus

        const v1 = pet1.velocidade + bonus1 * 100
        const v2 = pet2.velocidade + bonus2 * 100
        const chance1 = v1 / (v1 + v2)
        const venceu = Math.random() < chance1
        const premio = 150

        if (venceu) {
          u.moedas = sanearNum(u.moedas + premio)
          ganharXp(u, 15)
          salvarRpg(r)
          await sock.sendMessage(jid, {
            text: "🏁 *CORRIDA*\n\n" + pet1.emoji + " @" + numReal + " VS " + pet2.emoji + " @" + numAlvoReal + "\n\n🏆 *@" + numReal + " VENCEU!*\n💰 *+" + premio + "*",
            mentions: [mJid(numReal), mJid(numAlvoReal)]
          }, { quoted: msg })
        } else {
          uAlvo.moedas = sanearNum(uAlvo.moedas + premio)
          ganharXp(uAlvo, 15)
          salvarRpg(rAlvo)
          await sock.sendMessage(jid, {
            text: "🏁 *CORRIDA*\n\n" + pet1.emoji + " @" + numReal + " VS " + pet2.emoji + " @" + numAlvoReal + "\n\n🏆 *@" + numAlvoReal + " VENCEU!*\n💰 *+" + premio + "*",
            mentions: [mJid(numReal), mJid(numAlvoReal)]
          }, { quoted: msg })
        }
      }
    },

    perfil: {
      aliases: ["meuperfil", "rpgperfil"],
      async executar({ sock, msg, db, utils, sender }) {
        const jid = msg.key.remoteJid
        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const { u } = getRpg(num)

        const xpNec = xpNecessario(u.nivel)
        const pct = Math.floor(u.xp / xpNec * 10)
        const barra = "🟨".repeat(Math.min(10, pct)) + "⬛".repeat(Math.max(0, 10 - pct))

        const pet = u.pet ? PETS.find(p => p.id === u.pet) : null
        const petTxt = pet ? pet.emoji + " " + pet.nome : "❌ Sem pet"

        const txt =
`╔══════════════════════════════╗
║   🎩👤 𝐏𝐄𝐑𝐅𝐈𝐋 🎩👤
╚══════════════════════════════╝

👤 @${num}

━━━━━━━━━━━━━━━━━━━━━━━━━
🎖️ Nível: *${u.nivel}*
${barra} ${u.xp}/${xpNec} XP

💰 Carteira: *${fmt(u.moedas)}*

🐾 Pet: ${petTxt}

⛏️ Picareta: ${u.temPicareta ? "✅" : "❌"}
🎣 Vara: ${u.temVara ? "✅" : "❌"}`

        let fotoUrl = null
        try { fotoUrl = await sock.profilePictureUrl(mJid(num), "image") } catch (_) {}
        if (!fotoUrl) { try { fotoUrl = await sock.profilePictureUrl(sender, "image") } catch (_) {} }

        if (fotoUrl) {
          await sock.sendMessage(jid, { image: { url: fotoUrl }, caption: txt, mentions: [mJid(num)] }, { quoted: msg })
        } else {
          await sock.sendMessage(jid, { text: txt, mentions: [mJid(num)] }, { quoted: msg })
        }
      }
    },

    rank: {
      aliases: ["ranking", "top"],
      async executar({ sock, msg, db, utils }) {
        const jid = msg.key.remoteJid

        if (!jid.endsWith("@g.us")) {
          return sock.sendMessage(jid, { text: "🎩📊 O ranking só funciona em grupos!" }, { quoted: msg })
        }

        const { numeros } = await coletarMembros(sock, jid)

        if (numeros.size === 0) {
          return sock.sendMessage(jid, { text: "🎩💢 Não consegui identificar membros!" }, { quoted: msg })
        }

        const r = dbLer("rpg.json", { usuarios: {} })
        const lista = Object.entries(r.usuarios || {})
          .filter(([num]) => numeros.has(num))
          .map(([num, u]) => {
            let moedas = u.moedas || 0
            if (typeof moedas !== "number" || !isFinite(moedas) || moedas < 0) moedas = 0
            if (moedas > 999999999999) moedas = 999999999999
            return { num, moedas, nivel: u.nivel || 1 }
          })

        lista.sort((a, b) => b.moedas - a.moedas)
        const top = lista.slice(0, 10)

        if (!top.length) return sock.sendMessage(jid, { text: "🎩📊 Ninguém do grupo tá no RPG!" }, { quoted: msg })

        let txt = "╔══════════════════════════════╗\n║   🏆 𝐑𝐀𝐍𝐊𝐈𝐍𝐆 🏆\n╚══════════════════════════════╝\n\n"
        top.forEach((p, i) => {
          const medalha = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "▸"
          txt += medalha + " @" + p.num + "\n💰 *" + fmt(p.moedas) + "* | 🎖️ Nv " + p.nivel + "\n\n"
        })

        await sock.sendMessage(jid, { text: txt, mentions: top.map(p => mJid(p.num)) }, { quoted: msg })
      }
    },

    afk: {
      aliases: ["ausente"],
      async executar({ sock, msg, args, db, utils, sender }) {
        const jid = msg.key.remoteJid
        if (!jid.endsWith("@g.us")) return sock.sendMessage(jid, { text: "🎩💤 Use *!afk* apenas em grupos!" }, { quoted: msg })

        const num = await resolverNumero(sock, jid, sender) || utils.soNumero(sender)
        const motivo = args.join(" ").trim() || "Sem motivo"
        const afks = db.afk()
        afks[jid] = afks[jid] || {}
        afks[jid][sender] = { desde: Date.now(), motivo }
        afks[jid][mJid(num)] = { desde: Date.now(), motivo }
        db.salvarAfk(afks)

        await sock.sendMessage(jid, {
          text: "💤 *AFK ATIVADO*\n\n👤 @" + num + "\n📝 Motivo: *" + motivo + "*",
          mentions: [mJid(num)]
        }, { quoted: msg })
      }
    }

  }
}