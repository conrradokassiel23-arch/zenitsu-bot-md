/* ============================================================
   👑 MENU DONO - NAPOLEÃO BONAPARTE
   ============================================================ */

module.exports = {
  menu: "menu-dono",
  grupoOnly: false,
  adminOnly: false,
  donoOnly: true,

  commands: {

    // ============ MENUDONO ============
    menudono: {
      aliases: ["dono", "comandosdono", "menud", "imperador"],
      async executar({ sock, msg, prefixoAtivo, db }) {
        const jid = msg.key.remoteJid
        const p = prefixoAtivo
        const cfg = db.config()

        const texto = "╔══════════════════════════════╗\n" +
"║   👑  𝐂𝐎𝐌𝐀𝐍𝐃𝐎 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋  👑\n" +
"╚══════════════════════════════╝\n\n" +
"🎩 *Napoleão apresenta:*\n" +
"🦅 *as ordens do Imperador!*\n\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
"👁️ *EXÉRCITO*\n" +
"▸ " + p + "entrar <link>\n" +
"▸ " + p + "botoff\n" +
"▸ " + p + "reiniciar\n" +
"▸ " + p + "setfoto (reply img/vídeo)\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
"💎 *NOBREZA*\n" +
"▸ " + p + "addvip @user <tempo>\n" +
"▸ " + p + "delvip @user\n" +
"▸ " + p + "listavip\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
"👑 *MARECHAIS*\n" +
"▸ " + p + "addsubdono @user\n" +
"▸ " + p + "delsubdono @user\n" +
"▸ " + p + "listasubdono\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
"💰 *ALUGUEL DO TERRITÓRIO*\n" +
"▸ " + p + "aluguel on/off\n" +
"▸ " + p + "addaluguel <tempo>\n" +
"▸ " + p + "listaaluguel\n" +
"▸ " + p + "delaluguel <nome>\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
"⚙️ *ESTRATÉGIA*\n" +
"▸ " + p + "prefixoglobal <s>\n" +
"▸ " + p + "slow on/off\n" +
"▸ " + p + "canal <link>\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
"🚫 *BANIMENTO*\n" +
"▸ " + p + "banirgp\n" +
"▸ " + p + "desbanirgp\n" +
"▸ " + p + "listabangp\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
"💥 *DEVASTAÇÃO*\n" +
"▸ " + p + "nuke\n" +
"▸ " + p + "limpargp\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n\n" +
"🦅 _\"Um trono não se herda, se conquista.\"_\n" +
"🎩 _\"Finge que não viu... e não te faz mal\"_\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"

        if (cfg.fotoMenu) {
          const buf = Buffer.from(cfg.fotoMenu, "base64")
          if (cfg.tipoMenu === "video") return sock.sendMessage(jid, { video: buf, mimetype: "video/mp4", fileName: "napoleao-menu.mp4", gifPlayback: true, caption: texto }, { quoted: msg })
          return sock.sendMessage(jid, { image: buf, caption: texto }, { quoted: msg })
        }
        await sock.sendMessage(jid, { text: texto }, { quoted: msg })
      }
    },

    // ============ ENTRAR (link do grupo) ============
    entrar: {
      aliases: ["entrargp", "join", "joinlink"],
      async executar({ sock, msg, args }) {
        const jid = msg.key.remoteJid
        const link = args[0]

        if (!link) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n" +
"║   🚪 𝐄𝐍𝐓𝐑𝐀𝐑 𝐄𝐌 𝐓𝐄𝐑𝐑𝐈𝐓𝐎́𝐑𝐈𝐎\n" +
"╚══════════════════════════════╝\n\n" +
"🎩 Use: *!entrar <link do grupo>*\n\n" +
"🦅 Ex:\n" +
"   !entrar https://chat.whatsapp.com/ABC123XYZ\n\n" +
"⚔️ Napoleão vai:\n" +
"▸ 🚪 Entrar direto (se aberto)\n" +
"▸ 📨 Pedir permissão (se fechado)\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }

        const match = link.match(/chat\.whatsapp\.com\/([A-Za-z0-9]+)/)
        if (!match) {
          return sock.sendMessage(jid, {
            text: "⚔️ *Link inválido!*\n\n" +
"🎩 Use: *!entrar <link do grupo>*\n" +
"🦅 Ex: https://chat.whatsapp.com/ABC123"
          }, { quoted: msg })
        }

        const codigo = match[1]

        try {
          await sock.sendMessage(jid, {
            text: "🦅 *Napoleão vai entrar...*\n\n🎩 Link: " + link + "\n⏳ Aguarde..."
          }, { quoted: msg })

          let info
          try {
            info = await sock.groupAcceptInvite(codigo)
          } catch (e) {
            try {
              const meta = await sock.groupGetInviteInfo(codigo)
              info = await sock.groupAcceptInvite(codigo)
            } catch (e2) {
              return sock.sendMessage(jid, {
                text: "⚔️ *Não consegui entrar!*\n\n" +
"💢 Erro: " + e2.message + "\n\n" +
"🦅 Possíveis motivos:\n" +
"▸ 🚫 O bot foi banido do grupo\n" +
"▸ 📨 O grupo exige aprovação (pedido enviado)\n" +
"▸ ⏳ Link expirado\n" +
"▸ 🔗 Link inválido"
              }, { quoted: msg })
            }
          }

          const jidNovo = typeof info === "string" ? info : (info?.jid || "?")
          await sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n" +
"║   ✅ 𝐓𝐄𝐑𝐑𝐈𝐓𝐎́𝐑𝐈𝐎 𝐂𝐎𝐍𝐐𝐔𝐈𝐒𝐓𝐀𝐃𝐎\n" +
"╚══════════════════════════════╝\n\n" +
"🦅 *Napoleão entrou no grupo!*\n\n" +
"🎩 Grupo: " + jidNovo + "\n" +
"⚔️ Link: " + link + "\n\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
"👁️ _\"Mais um território sob o império.\"_\n" +
"🎩 _\"Finge que não viu...\"_"
          }, { quoted: msg })

        } catch (e) {
          try {
            await sock.sendMessage(jid, {
              text: "📨 *Enviando pedido de entrada...*\n\n" +
"🎩 Napoleão vai pedir pra entrar no grupo...\n" +
"⏳ Aguarde aprovação do admin."
            }, { quoted: msg })

            await sock.groupAcceptInvite(codigo)

            await sock.sendMessage(jid, {
              text: "╔══════════════════════════════╗\n" +
"║   📨 𝐏𝐄𝐃𝐈𝐃𝐎 𝐄𝐍𝐕𝐈𝐀𝐃𝐎\n" +
"╚══════════════════════════════╝\n\n" +
"🦅 Napoleão pediu pra entrar no grupo!\n\n" +
"🎩 Link: " + link + "\n" +
"⚔️ Aguarde a aprovação do administrador.\n\n" +
"━━━━━━━━━━━━━━━━━━━━━━━━━\n" +
"👁️ _\"Paciência é uma virtude militar.\"_"
            }, { quoted: msg })

          } catch (e2) {
            await sock.sendMessage(jid, {
              text: "⚔️ *Erro ao entrar no grupo!*\n\n" +
"💢 " + e2.message + "\n\n" +
"🦅 Verifique:\n" +
"▸ O link tá correto?\n" +
"▸ O bot foi banido?\n" +
"▸ Já está no grupo?"
            }, { quoted: msg })
          }
        }
      }
    },

    // ============ BOTOFF ============
    botoff: {
      aliases: ["desligar", "offbot"],
      async executar({ sock, msg }) {
        const jid = msg.key.remoteJid
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n" +
"║   🎩 𝐀𝐓𝐄́ 𝐋𝐎𝐆𝐎, 𝐈𝐌𝐏𝐄́𝐑𝐈𝐎\n" +
"╚══════════════════════════════╝\n\n" +
"🦅 *Napoleão está desligando...*\n\n" +
"⚔️ _\"Não existe vitória eterna.\"_\n" +
"🎩 _\"Finge que não viu...\"_\n" +
"👁️ _\"...e não te faz mal.\"_\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
        setTimeout(() => process.exit(0), 2000)
      }
    },

    // ============ REINICIAR ============
    reiniciar: {
      aliases: ["restart"],
      async executar({ sock, msg }) {
        const jid = msg.key.remoteJid
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n" +
"║   🔄 𝐑𝐄𝐄𝐑𝐆𝐔𝐄𝐑 𝐎 𝐈𝐌𝐏𝐄́𝐑𝐈𝐎\n" +
"╚══════════════════════════════╝\n\n" +
"🦅 *Napoleão vai renascer...*\n\n" +
"⚔️ _\"A águia volta a voar.\"_\n" +
"🎩 _Aguarde alguns instantes..._\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
        setTimeout(() => process.exit(0), 2000)
      }
    },

    // ============ SETFOTO (CORRIGIDO - VÍDEO VIRA GIF) ============
    setfoto: {
      aliases: ["fotomenu", "videomenu"],
      async executar({ sock, msg, db, utils }) {
        const jid = msg.key.remoteJid
        const fs = require("fs")
        const path = require("path")
        const os = require("os")
        const { execSync } = require("child_process")

        const ctx = msg.message?.extendedTextMessage?.contextInfo || {}
        const quoted = ctx.quotedMessage
        const temImg = msg.message?.imageMessage || quoted?.imageMessage
        const temVid = msg.message?.videoMessage || quoted?.videoMessage

        if (!temImg && !temVid) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n" +
"║   🖼️ 𝐄𝐒𝐓𝐀𝐍𝐃𝐀𝐑𝐓𝐄 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋\n" +
"╚══════════════════════════════╝\n\n" +
"🎩 *Mande ou responda uma mídia:*\n\n" +
"▸ 🖼️ Imagem → vira estandarte fixo\n" +
"▸ 🎬 Vídeo → vira GIF animado!\n\n" +
"🦅 Ex: *!setfoto* (reply)\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }

        try {
          const cfg = db.config()

          if (temImg) {
            const alvoMsg = msg.message?.imageMessage ? msg : { ...msg, message: { imageMessage: quoted.imageMessage } }
            const buffer = await utils.downloadMediaMessage(alvoMsg, "buffer", {}, { logger: console, reuploadRequest: sock.updateMediaMessage })
            cfg.fotoMenu = buffer.toString("base64")
            cfg.tipoMenu = "foto"
            db.salvarConfig(cfg)
            return sock.sendMessage(jid, {
              image: buffer,
              caption: "╔══════════════════════════════╗\n" +
"║   🖼️ 𝐄𝐒𝐓𝐀𝐍𝐃𝐀𝐑𝐓𝐄 𝐒𝐀𝐋𝐕𝐎\n" +
"╚══════════════════════════════╝\n\n" +
"🦅 A imagem vai aparecer nos menus!\n\n" +
"🎩 _\"Um bom general conhece seu estandarte.\"_\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
            }, { quoted: msg })
          }

          const vidMsg = msg.message?.videoMessage ? msg : { ...msg, message: { videoMessage: quoted.videoMessage } }
          const vidBuffer = await utils.downloadMediaMessage(vidMsg, "buffer", {}, { logger: console, reuploadRequest: sock.updateMediaMessage })

          const ff = require("@ffmpeg-installer/ffmpeg").path
          const tmp = os.tmpdir()
          const tIn = path.join(tmp, "menu_" + Date.now() + ".mp4")
          const tOut = path.join(tmp, "menu_" + Date.now() + "_out.mp4")
          fs.writeFileSync(tIn, vidBuffer)

          execSync('"' + ff + '" -y -i "' + tIn + '" -t 8 -vf "fps=15,scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=black" -an -c:v libx264 -preset fast -crf 28 -pix_fmt yuv420p -movflags +faststart "' + tOut + '"', { stdio: "ignore" })

          const outBuffer = fs.readFileSync(tOut)
          cfg.fotoMenu = outBuffer.toString("base64")
          cfg.tipoMenu = "video"
          db.salvarConfig(cfg)

          try { fs.unlinkSync(tIn); fs.unlinkSync(tOut) } catch(_){}

          await sock.sendMessage(jid, {
            video: outBuffer,
            mimetype: "video/mp4",
            fileName: "napoleao-menu.mp4",
            gifPlayback: true,
            caption: "╔══════════════════════════════╗\n" +
"║   🎬 𝐄𝐒𝐓𝐀𝐍𝐃𝐀𝐑𝐓𝐄 𝐀𝐍𝐈𝐌𝐀𝐃𝐎\n" +
"╚══════════════════════════════╝\n\n" +
"🦅 O vídeo vai aparecer como *GIF* nos menus!\n\n" +
"🎩 _\"Movimento conquista impérios.\"_\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        } catch (e) {
          await sock.sendMessage(jid, { text: "⚔️ Erro: " + e.message }, { quoted: msg })
        }
      }
    },

    // ============ ADDVIP ============
    addvip: {
      aliases: ["darvip", "setvip"],
      async executar({ sock, msg, args, db, utils }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n" +
"║   💎 𝐍𝐎𝐁𝐑𝐄𝐙𝐀 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋\n" +
"╚══════════════════════════════╝\n\n" +
"🎩 Use: *!addvip @user <tempo>*\n\n" +
"▸ 💎 1d — 1 dia\n" +
"▸ 💎 7d — 7 dias\n" +
"▸ 💎 30d — 30 dias\n" +
"▸ ♾️ inf — eterno\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        const tempo = (args.find(a => /^(inf|\d+[dhm])$/i.test(a)) || "").toLowerCase()
        if (!tempo) {
          return sock.sendMessage(jid, { text: "🎩 Use: *!addvip @user <tempo>*" }, { quoted: msg })
        }
        let expira = "inf"
        if (tempo !== "inf") {
          const v = parseInt(tempo)
          const u = tempo.slice(-1)
          let ms = 0
          if (u === "d") ms = v * 24 * 60 * 60 * 1000
          if (u === "h") ms = v * 60 * 60 * 1000
          if (u === "m") ms = v * 60 * 1000
          expira = Date.now() + ms
        }
        const v = db.vips()
        v.vips = v.vips || {}
        v.vips[alvo] = { expira, desde: Date.now() }
        db.salvarVips(v)
        const num = utils.soNumero(alvo)
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n" +
"║   💎 𝐍𝐎𝐁𝐑𝐄 𝐀𝐃𝐈𝐂𝐈𝐎𝐍𝐀𝐃𝐎\n" +
"╚══════════════════════════════╝\n\n" +
"👤 @" + num + "\n" +
"💎 Nobreza: *" + (tempo === "inf" ? "ETERNA ♾️" : tempo.toUpperCase()) + "*\n\n" +
"🎩 _\"Bem-vindo à corte.\"_\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯",
          mentions: [alvo]
        }, { quoted: msg })
      }
    },

    // ============ DELVIP ============
    delvip: {
      aliases: ["rmvip", "removervip"],
      async executar({ sock, msg, db, utils }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) return sock.sendMessage(jid, { text: "🎩 Use: *!delvip @user*" }, { quoted: msg })
        const v = db.vips()
        const num = utils.soNumero(alvo)
        if (!v.vips?.[alvo]) {
          return sock.sendMessage(jid, { text: "⚔️ @" + num + " não é nobre!", mentions: [alvo] }, { quoted: msg })
        }
        delete v.vips[alvo]
        db.salvarVips(v)
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n" +
"║   ⚔️ 𝐍𝐎𝐁𝐑𝐄𝐙𝐀 𝐑𝐄𝐓𝐈𝐑𝐀𝐃𝐀\n" +
"╚══════════════════════════════╝\n\n" +
"👤 @" + num + "\n\n" +
"🦅 _\"Volte para a tropa.\"_\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯",
          mentions: [alvo]
        }, { quoted: msg })
      }
    },

    // ============ LISTAVIP ============
    listavip: {
      aliases: ["vips", "vervips"],
      async executar({ sock, msg, db, utils }) {
        const jid = msg.key.remoteJid
        const v = db.vips()
        const vips = Object.entries(v.vips || {})
        if (!vips.length) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n" +
"║   💎 𝐋𝐈𝐒𝐓𝐀 𝐃𝐀 𝐍𝐎𝐁𝐑𝐄𝐙𝐀\n" +
"╚══════════════════════════════╝\n\n" +
"🔮 Nenhum nobre registrado~\n" +
"🎩 Adicione com *!addvip*\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        let txt = "╔══════════════════════════════╗\n║   💎 𝐍𝐎𝐁𝐑𝐄𝐙𝐀 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋\n╚══════════════════════════════╝\n\n"
        const mentions = []
        vips.forEach(([jidVip, info], i) => {
          const num = utils.soNumero(jidVip)
          const expira = info.expira === "inf" ? "♾️ Eterno" : new Date(info.expira).toLocaleString("pt-BR")
          txt += "👑 " + (i + 1) + ". @" + num + "\n💎 Expira: " + expira + "\n\n"
          mentions.push(jidVip)
        })
        await sock.sendMessage(jid, { text: txt, mentions }, { quoted: msg })
      }
    },

    // ============ ALUGUEL ============
    aluguel: {
      aliases: ["modoaluguel", "sistaluguel"],
      async executar({ sock, msg, args, db }) {
        const jid = msg.key.remoteJid
        const opcao = (args[0] || "").toLowerCase()
        const a = db.aluguel()

        if (!["on", "off"].includes(opcao)) {
          const grupos = Object.keys(a.grupos || {}).length
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n" +
"║   💰 𝐀𝐋𝐔𝐆𝐔𝐄𝐋 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋\n" +
"╚══════════════════════════════╝\n\n" +
"🎩 Status: *" + (a.ativo ? "ON ✅" : "OFF ❌") + "*\n" +
"🏰 Territórios alugados: *" + grupos + "*\n\n" +
"🦅 Use *!aluguel on/off*\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }

        a.ativo = opcao === "on"
        db.salvarAluguel(a)
        await sock.sendMessage(jid, {
          text: opcao === "on"
            ? "╔══════════════════════════════╗\n║   💰 𝐀𝐋𝐔𝐆𝐔𝐄𝐋 𝐀𝐓𝐈𝐕𝐎\n╚══════════════════════════════╝\n\n⚔️ Agora territórios precisam de aluguel!\n\n🦅 _\"Ninguém ocupa terras de graça.\"_\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
            : "╔══════════════════════════════╗\n║   ⚔️ 𝐀𝐋𝐔𝐆𝐔𝐄𝐋 𝐃𝐄𝐒𝐀𝐓𝐈𝐕𝐀𝐃𝐎\n╚══════════════════════════════╝\n\n🦅 Napoleão libera territórios grátis!\n\n🎩 _\"Generosidade fortalece.\"_\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
      }
    },

    // ============ ADDALUGUEL ============
    addaluguel: {
      aliases: ["davaluguel", "setaluguel"],
      grupoOnly: true,
      async executar({ sock, msg, args, db, utils }) {
        const jid = msg.key.remoteJid
        const tempoStr = args.join(" ").trim().toLowerCase()

        if (!tempoStr) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n" +
"║   ⏰ 𝐀𝐃𝐃𝐀𝐋𝐔𝐆𝐔𝐄𝐋\n" +
"╚══════════════════════════════╝\n\n" +
"🎩 Use: *!addaluguel <tempo>*\n\n" +
"▸ 30min\n" +
"▸ 1h\n" +
"▸ 1d / 1dia\n" +
"▸ 1sem\n" +
"▸ 1mes\n" +
"▸ 1ano\n\n" +
"🦅 Pode somar: *1dia 1mes*\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }

        const partes = tempoStr.split(/\s+/)
        let totalMs = 0
        const descritivo = []

        for (const p of partes) {
          const m = p.match(/^(\d+)(min|h|dia|d|sem|mes|ano)$/)
          if (!m) continue
          const v = parseInt(m[1])
          const u = m[2]
          let ms = 0, txt = ""
          if (u === "min") { ms = v * 60 * 1000; txt = v + "min" }
          else if (u === "h") { ms = v * 60 * 60 * 1000; txt = v + "h" }
          else if (u === "d" || u === "dia") { ms = v * 24 * 60 * 60 * 1000; txt = v + "dia" }
          else if (u === "sem") { ms = v * 7 * 24 * 60 * 60 * 1000; txt = v + "sem" }
          else if (u === "mes") { ms = v * 30 * 24 * 60 * 60 * 1000; txt = v + "mes" }
          else if (u === "ano") { ms = v * 365 * 24 * 60 * 60 * 1000; txt = v + "ano" }
          totalMs += ms
          descritivo.push(txt)
        }

        if (totalMs <= 0) {
          return sock.sendMessage(jid, { text: "⚔️ Formato inválido!\n🎩 Use: *30min*, *1h*, *1dia*, *1sem*, *1mes*, *1ano*" }, { quoted: msg })
        }

        const a = db.aluguel()
        a.grupos = a.grupos || {}
        const agora = Date.now()
        const atual = (a.grupos[jid] > agora) ? a.grupos[jid] : agora
        a.grupos[jid] = atual + totalMs
        if (!a.ativo) a.ativo = true
        db.salvarAluguel(a)

        const restante = a.grupos[jid] - agora
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n" +
"║   ✅ 𝐀𝐋𝐔𝐆𝐔𝐄𝐋 𝐀𝐃𝐈𝐂𝐈𝐎𝐍𝐀𝐃𝐎\n" +
"╚══════════════════════════════╝\n\n" +
"💰 Adicionado: *+" + descritivo.join(" + ") + "*\n" +
"⏰ Expira em: *" + utils.formatarTempo(restante) + "*\n\n" +
"🦅 _\"Território garantido.\"_\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
      }
    },

    // ============ LISTAALUGUEL ============
    listaaluguel: {
      aliases: ["alugueis", "veralugueis"],
      async executar({ sock, msg, db, utils }) {
        const jid = msg.key.remoteJid
        const a = db.aluguel()
        const agora = Date.now()
        const entradas = Object.entries(a.grupos || {}).filter(([_, exp]) => exp > agora)

        if (!entradas.length) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n" +
"║   💰 𝐋𝐈𝐒𝐓𝐀 𝐃𝐄 𝐀𝐋𝐔𝐆𝐔𝐄𝐈𝐒\n" +
"╚══════════════════════════════╝\n\n" +
"🔮 Nenhum território alugado~\n\n" +
"🎩 Adicione com *!addaluguel*\n\n" +
"╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }

        let txt = "╔══════════════════════════════╗\n║   💰 𝐓𝐄𝐑𝐑𝐈𝐓𝐎́𝐑𝐈𝐎𝐒 𝐀𝐋𝐔𝐆𝐀𝐃𝐎𝐒\n╚══════════════════════════════╝\n📊 Total: *" + entradas.length + "*\n\n"
        const mentions = []

        for (const [jidG, exp] of entradas) {
          const restante = exp - agora
          try {
            const meta = await sock.groupMetadata(jidG)
            const nome = meta.subject || "Sem nome"
            const superadmin = meta.participants.find(p => p.admin === "superadmin")
            const donoNum = superadmin ? superadmin.id.split("@")[0] : "?"
            txt += "🏰 *" + nome + "*\n👑 Líder: @" + donoNum + "\n⏰ Restante: *" + utils.formatarTempo(restante) + "*\n\n"
            if (superadmin) mentions.push(superadmin.id)
          } catch (_) {
            txt += "🏰 *" + jidG + "*\n⏰ Restante: *" + utils.formatarTempo(restante) + "*\n\n"
          }
        }

        await sock.sendMessage(jid, { text: txt, mentions }, { quoted: msg })
      }
    },

    // ============ DELALUGUEL ============
    delaluguel: {
      aliases: ["rmaluguel", "removeraluguel"],
      async executar({ sock, msg, args, db }) {
        const jid = msg.key.remoteJid
        const a = db.aluguel()
        a.grupos = a.grupos || {}

        if (!args.length && jid.endsWith("@g.us")) {
          if (!a.grupos[jid]) {
            return sock.sendMessage(jid, { text: "⚔️ Esse território não tem aluguel!" }, { quoted: msg })
          }
          delete a.grupos[jid]
          db.salvarAluguel(a)
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   ✅ 𝐀𝐋𝐔𝐆𝐔𝐄𝐋 𝐑𝐄𝐌𝐎𝐕𝐈𝐃𝐎\n╚══════════════════════════════╝\n\n🦅 O aluguel deste território foi removido!\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }

        const nome = args.join(" ").trim().toLowerCase()
        if (!nome) {
          return sock.sendMessage(jid, { text: "🦅 Use: *!delaluguel <nome do grupo>*\n🎩 Ou em grupo: *!delaluguel*" }, { quoted: msg })
        }

        let encontrado = null
        for (const jidG of Object.keys(a.grupos)) {
          try {
            const meta = await sock.groupMetadata(jidG)
            if ((meta.subject || "").toLowerCase().includes(nome)) { encontrado = jidG; break }
          } catch (_) {}
        }

        if (!encontrado) {
          return sock.sendMessage(jid, { text: "⚔️ Não achei nenhum território com *\"" + nome + "\"*" }, { quoted: msg })
        }

        delete a.grupos[encontrado]
        db.salvarAluguel(a)
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   ✅ 𝐀𝐋𝐔𝐆𝐔𝐄𝐋 𝐑𝐄𝐌𝐎𝐕𝐈𝐃𝐎\n╚══════════════════════════════╝\n\n🏰 Território: *" + nome + "*\n\n🦅 _\"Libertado do imposto.\"_\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
      }
    },

    // ============ ADDSUBDONO ============
    addsubdono: {
      aliases: ["addsub", "darsub"],
      async executar({ sock, msg, db, utils }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) return sock.sendMessage(jid, { text: "👑 Use: *!addsubdono @user*" }, { quoted: msg })
        const cfg = db.config()
        cfg.subdonos = cfg.subdonos || []
        const num = utils.soNumero(alvo)
        if (cfg.subdonos.some(s => utils.soNumero(s) === num)) {
          return sock.sendMessage(jid, { text: "🎩 @" + num + " já é Marechal!", mentions: [alvo] }, { quoted: msg })
        }
        cfg.subdonos.push(alvo)
        db.salvarConfig(cfg)
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   👑 𝐍𝐎𝐕𝐎 𝐌𝐀𝐑𝐄𝐂𝐇𝐀𝐋\n╚══════════════════════════════╝\n\n👤 @" + num + "\n\n🦅 _\"O poder exige responsabilidade.\"_\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯",
          mentions: [alvo]
        }, { quoted: msg })
      }
    },

    // ============ DELSUBDONO ============
    delsubdono: {
      aliases: ["delsub", "rmsub", "rmsubdono"],
      async executar({ sock, msg, db, utils }) {
        const jid = msg.key.remoteJid
        const alvo = utils.getAlvo(msg)
        if (!alvo) return sock.sendMessage(jid, { text: "👑 Use: *!delsubdono @user*" }, { quoted: msg })
        const cfg = db.config()
        const num = utils.soNumero(alvo)
        cfg.subdonos = (cfg.subdonos || []).filter(s => utils.soNumero(s) !== num)
        db.salvarConfig(cfg)
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   ⚔️ 𝐌𝐀𝐑𝐄𝐂𝐇𝐀𝐋 𝐑𝐄𝐓𝐈𝐑𝐀𝐃𝐎\n╚══════════════════════════════╝\n\n👤 @" + num + "\n\n🦅 _\"Volte ao front, soldado.\"_\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯",
          mentions: [alvo]
        }, { quoted: msg })
      }
    },

    // ============ LISTASUBDONO ============
    listasubdono: {
      aliases: ["subdonos", "listasub"],
      async executar({ sock, msg, db, utils }) {
        const jid = msg.key.remoteJid
        const cfg = db.config()
        const subs = cfg.subdonos || []
        if (!subs.length) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   👑 𝐋𝐈𝐒𝐓𝐀 𝐃𝐄 𝐌𝐀𝐑𝐄𝐂𝐇𝐀𝐈𝐒\n╚══════════════════════════════╝\n\n🔮 Nenhum marechal nomeado~\n\n🦅 Adicione com *!addsubdono*\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        let txt = "╔══════════════════════════════╗\n║   👑 𝐌𝐀𝐑𝐄𝐂𝐇𝐀𝐈𝐒 𝐃𝐎 𝐈𝐌𝐏𝐄́𝐑𝐈𝐎\n╚══════════════════════════════╝\n\n"
        const mentions = []
        subs.forEach((jidS, i) => {
          txt += "🎩 " + (i + 1) + ". @" + utils.soNumero(jidS) + "\n"
          mentions.push(jidS)
        })
        await sock.sendMessage(jid, { text: txt, mentions }, { quoted: msg })
      }
    },

    // ============ PREFIXOGLOBAL ============
    prefixoglobal: {
      aliases: ["setprefixoglobal"],
      async executar({ sock, msg, args, db }) {
        const jid = msg.key.remoteJid
        const p = args[0]
        if (!p || p.length > 3) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   ⚙️ 𝐏𝐑𝐄𝐅𝐈𝐗𝐎 𝐆𝐋𝐎𝐁𝐀𝐋\n╚══════════════════════════════╝\n\n🎩 Use: *!prefixoglobal <prefixo>*\n\n🦅 Máx 3 caracteres\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        const cfg = db.config()
        cfg.prefixoGlobal = p
        db.salvarConfig(cfg)
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   ⚙️ 𝐏𝐑𝐄𝐅𝐈𝐗𝐎 𝐀𝐓𝐔𝐀𝐋𝐈𝐙𝐀𝐃𝐎\n╚══════════════════════════════╝\n\n⚔️ Novo prefixo: *" + p + "*\n\n🦅 _\"Ordens com clareza.\"_\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
      }
    },

    // ============ SLOW ============
    slow: {
      aliases: ["modolento"],
      async executar({ sock, msg, args, db }) {
        const jid = msg.key.remoteJid
        const opcao = (args[0] || "").toLowerCase()
        if (!["on", "off"].includes(opcao)) {
          const cfg = db.config()
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   ⚙️ 𝐌𝐎𝐃𝐎 𝐋𝐄𝐍𝐓𝐎\n╚══════════════════════════════╝\n\n🎩 Status: *" + (cfg.slow ? "ON" : "OFF") + "*\n\n🦅 Use *!slow on/off*\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        const cfg = db.config()
        cfg.slow = opcao === "on"
        db.salvarConfig(cfg)
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   ⚙️ 𝐌𝐎𝐃𝐎 𝐋𝐄𝐍𝐓𝐎\n╚══════════════════════════════╝\n\n🦅 Status: *" + opcao.toUpperCase() + "*\n\n🎩 " + (opcao === "on" ? "Napoleão vai responder devagar~" : "Napoleão tá veloz!") + "\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
      }
    },

    // ============ CANAL ============
    canal: {
      aliases: ["setcanal"],
      async executar({ sock, msg, args, db, utils }) {
        const jid = msg.key.remoteJid
        const link = args[0]
        if (!link) {
          const c = db.canal()
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   📢 𝐂𝐀𝐍𝐀𝐋 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋\n╚══════════════════════════════╝\n\n🔮 Atual: " + (c?.jid ? c.nome : "❌ Nenhum") + "\n\n🎩 Use: *!canal <link>*\n🦅 Ou: *!canal off*\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        if (link.toLowerCase() === "off") {
          db.salvarCanal({ jid: null, nome: null, link: null })
          utils.recarregarCanal()
          return sock.sendMessage(jid, { text: "╔══════════════════════════════╗\n║   📢 𝐂𝐀𝐍𝐀𝐋 𝐑𝐄𝐌𝐎𝐕𝐈𝐃𝐎\n╚══════════════════════════════╝\n\n🦅 Canal desativado!\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯" }, { quoted: msg })
        }
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   📢 𝐂𝐀𝐍𝐀𝐋\n╚══════════════════════════════╝\n\n🎩 Use o console do servidor:\n   *canal <link>*\n\n🦅 Link: whatsapp.com/channel/...\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
      }
    },

    // ============ BANIRGP ============
    banirgp: {
      aliases: ["bangp", "banirgrupo"],
      async executar({ sock, msg, db }) {
        const jid = msg.key.remoteJid
        const b = db.bangp()
        b.grupos = b.grupos || {}
        b.grupos[jid] = true
        db.salvarBangp(b)
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   🚫 𝐓𝐄𝐑𝐑𝐈𝐓𝐎́𝐑𝐈𝐎 𝐁𝐀𝐍𝐈𝐃𝐎\n╚══════════════════════════════╝\n\n🦅 Napoleão baniu este território!\n\n🎩 _\"Finge que não viu...\"_\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
      }
    },

    // ============ DESBANIRGP ============
    desbanirgp: {
      aliases: ["desbangp"],
      async executar({ sock, msg, db }) {
        const jid = msg.key.remoteJid
        const b = db.bangp()
        if (b.grupos?.[jid]) {
          delete b.grupos[jid]
          db.salvarBangp(b)
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   ✅ 𝐓𝐄𝐑𝐑𝐈𝐓𝐎́𝐑𝐈𝐎 𝐋𝐈𝐁𝐄𝐑𝐀𝐃𝐎\n╚══════════════════════════════╝\n\n🦅 Napoleão perdoou este território!\n\n🎩 _\"Piedade fortalece o império.\"_\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        await sock.sendMessage(jid, { text: "⚔️ Esse território não está banido!" }, { quoted: msg })
      }
    },

    // ============ LISTABANGP ============
    listabangp: {
      aliases: ["gruposbanidos"],
      async executar({ sock, msg, db }) {
        const jid = msg.key.remoteJid
        const b = db.bangp()
        const grupos = Object.keys(b.grupos || {})
        if (!grupos.length) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   🚫 𝐓𝐄𝐑𝐑𝐈𝐓𝐎́𝐑𝐈𝐎𝐒 𝐁𝐀𝐍𝐈𝐃𝐎𝐒\n╚══════════════════════════════╝\n\n🔮 Nenhum território banido~\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        let txt = "╔══════════════════════════════╗\n║   🚫 𝐓𝐄𝐑𝐑𝐈𝐓𝐎́𝐑𝐈𝐎𝐒 𝐁𝐀𝐍𝐈𝐃𝐎𝐒\n╚══════════════════════════════╝\n\n"
        grupos.forEach((g, i) => { txt += "⚔️ " + (i + 1) + ". " + g + "\n" })
        await sock.sendMessage(jid, { text: txt }, { quoted: msg })
      }
    },

    // ============ NUKE ============
    nuke: {
      aliases: ["explodir", "destruir"],
      async executar({ sock, msg, groupMetadata, utils }) {
        const jid = msg.key.remoteJid
        if (!jid.endsWith("@g.us")) return
        if (!utils.botEhAdmin(groupMetadata, sock)) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   💥 𝐍𝐔𝐊𝐄\n╚══════════════════════════════╝\n\n👁️ Napoleão precisa ser *admin*!\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   💥 𝐃𝐄𝐕𝐀𝐒𝐓𝐀𝐐𝐀̃𝐎\n╚══════════════════════════════╝\n\n🦅 Napoleão tá explodindo o território...\n\n🎩 _\"Não olha pra trás...\"_\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
        const meta = await sock.groupMetadata(jid)
        const botNum = utils.soNumero(sock.user?.id)
        const alvos = meta.participants.filter(p => utils.soNumero(p.id) !== botNum).map(p => p.id)
        for (const a of alvos) {
          try { await sock.groupParticipantsUpdate(jid, [a], "remove") } catch (_) {}
          await new Promise(r => setTimeout(r, 500))
        }
      }
    },

    // ============ LIMPARGP ============
    limpargp: {
      aliases: ["limpargrupo"],
      async executar({ sock, msg, groupMetadata, utils }) {
        const jid = msg.key.remoteJid
        if (!jid.endsWith("@g.us")) return
        if (!utils.botEhAdmin(groupMetadata, sock)) {
          return sock.sendMessage(jid, {
            text: "╔══════════════════════════════╗\n║   🧹 𝐋𝐈𝐌𝐏𝐀𝐑\n╚══════════════════════════════╝\n\n👁️ Napoleão precisa ser *admin*!\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
          }, { quoted: msg })
        }
        await sock.sendMessage(jid, {
          text: "╔══════════════════════════════╗\n║   🧹 𝐋𝐈𝐌𝐏𝐄𝐙𝐀 𝐈𝐌𝐏𝐄𝐑𝐈𝐀𝐋\n╚══════════════════════════════╝\n\n🦅 Napoleão tá limpando a tropa...\n\n🎩 Aguarde~\n\n╰━━━━━━━━━━━━━━━━━━━━━━━━━╯"
        }, { quoted: msg })
        const meta = await sock.groupMetadata(jid)
        const botNum = utils.soNumero(sock.user?.id)
        const alvos = meta.participants.filter(p => {
          if (utils.soNumero(p.id) === botNum) return false
          if (p.admin === "admin" || p.admin === "superadmin") return false
          return true
        }).map(p => p.id)
        for (const a of alvos) {
          try { await sock.groupParticipantsUpdate(jid, [a], "remove") } catch (_) {}
          await new Promise(r => setTimeout(r, 500))
        }
      }
    }

  }
}